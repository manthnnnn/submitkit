import { ThreatAnalysis } from './threat-data';

// Homograph Cyrillic to Latin character mappings
const HOMOGRAPH_MAP: Record<string, string> = {
  '\u0430': 'a', // cyrillic small a
  '\u0441': 'c', // cyrillic small es
  '\u0435': 'e', // cyrillic small ie
  '\u043E': 'o', // cyrillic small o
  '\u0440': 'p', // cyrillic small er
  '\u0455': 's', // cyrillic small dze
  '\u0445': 'x', // cyrillic small ha
  '\u0443': 'y', // cyrillic small u
};

// Calculate Shannon entropy of string
export function calculateEntropy(str: string): number {
  const len = str.length;
  if (len === 0) return 0;
  const freq: Record<string, number> = {};
  for (let i = 0; i < len; i++) {
    const c = str[i];
    freq[c] = (freq[c] || 0) + 1;
  }
  let entropy = 0;
  for (const c in freq) {
    const p = freq[c] / len;
    entropy -= p * Math.log2(p);
  }
  return Number(entropy.toFixed(2));
}

// Analyze any arbitrary URL
export function analyzeURL(inputUrl: string): ThreatAnalysis {
  let cleanUrl = inputUrl.trim();
  if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
    cleanUrl = 'https://' + cleanUrl;
  }

  let parsed: URL;
  try {
    parsed = new URL(cleanUrl);
  } catch (e) {
    // Fallback if malformed
    return {
      id: `SCAN-${Math.floor(1000 + Math.random() * 9000)}`,
      url: inputUrl,
      domain: inputUrl,
      threatLevel: 'CRITICAL_PHISHING',
      riskScore: 92,
      targetedBrand: 'Malformed Malicious URI',
      attackVector: 'Buffer Overflow / URI Injection Scheme',
      ipAddress: '0.0.0.0',
      serverCountry: 'Unknown Proxy',
      domainAgeDays: 0,
      sslValid: false,
      sslIssuer: 'None',
      lexicalFlags: ['Malformed URL structure', 'Non-standard scheme encoding'],
      heuristicReasons: ['Browser RFC violation: unable to safely parse hostname.'],
      status: 'BLOCKED',
      timestamp: 'Just now'
    };
  }

  const hostname = parsed.hostname.toLowerCase();
  const pathname = parsed.pathname.toLowerCase();
  const lexicalFlags: string[] = [];
  const heuristicReasons: string[] = [];
  let score = 5; // Base clean score

  // 1. Homograph Check
  let hasHomograph = false;
  for (const cyr in HOMOGRAPH_MAP) {
    if (hostname.includes(cyr)) {
      hasHomograph = true;
      lexicalFlags.push(`Unicode Homograph Detected: Cyrillic character '${cyr}' impersonating Latin '${HOMOGRAPH_MAP[cyr]}'`);
      heuristicReasons.push('Attacker used internationalized domain spoofing (IDN Homograph) to deceive users visually.');
      score += 55;
      break;
    }
  }

  // 2. High-Risk TLDs
  const suspiciousTLDs = ['.ru', '.top', '.xyz', '.click', '.online', '.tk', '.ml', '.ga', '.cf'];
  for (const tld of suspiciousTLDs) {
    if (hostname.endsWith(tld)) {
      lexicalFlags.push(`Suspicious TLD: ${tld} commonly abused in automated phishing kits`);
      score += 25;
      break;
    }
  }

  // 3. Keyword Stuffing
  const brandKeywords = ['paypal', 'microsoft', 'google', 'apple', 'netflix', 'amazon', 'chase', 'bank', 'login', 'verify', 'account', 'security', 'billing'];
  const matchedKeywords = brandKeywords.filter(k => hostname.includes(k) || pathname.includes(k));
  if (matchedKeywords.length >= 2) {
    lexicalFlags.push(`Keyword stuffing detected: [${matchedKeywords.join(', ')}] in URI`);
    score += 20;
  }

  // 4. Subdomain Depth
  const subdomains = hostname.split('.');
  if (subdomains.length >= 4) {
    lexicalFlags.push(`Excessive subdomain depth (${subdomains.length} levels) indicative of bulletproof proxy routing`);
    score += 18;
  }

  // 5. Entropy
  const entropy = calculateEntropy(hostname);
  if (entropy > 3.8) {
    lexicalFlags.push(`High Shannon entropy (${entropy}): randomly generated domain name algorithm (DGA)`);
    score += 20;
  }

  // Cap score 0 - 100
  const finalScore = Math.min(Math.max(score, 2), 99);
  let threatLevel: 'SAFE' | 'SUSPICIOUS' | 'CRITICAL_PHISHING' = 'SAFE';
  let status: 'BLOCKED' | 'QUARANTINED' | 'CLEARED' = 'CLEARED';

  if (finalScore >= 75) {
    threatLevel = 'CRITICAL_PHISHING';
    status = 'BLOCKED';
    if (heuristicReasons.length === 0) {
      heuristicReasons.push('Multiple combined lexical red flags indicate an active phishing kit.');
    }
  } else if (finalScore >= 40) {
    threatLevel = 'SUSPICIOUS';
    status = 'QUARANTINED';
    heuristicReasons.push('Unusual URL structure requiring step-up sandbox inspection.');
  } else {
    threatLevel = 'SAFE';
    status = 'CLEARED';
    heuristicReasons.push('Clean domain structure. No deceptive homographs or credential harvesting patterns.');
  }

  return {
    id: `SCAN-${Math.floor(1000 + Math.random() * 9000)}`,
    url: cleanUrl,
    domain: hostname,
    threatLevel,
    riskScore: finalScore,
    targetedBrand: matchedKeywords.length > 0 ? `${matchedKeywords[0].toUpperCase()} Impersonation` : 'Generic Entity',
    attackVector: hasHomograph ? 'Cyrillic Homograph Phishing' : finalScore >= 75 ? 'Credential Harvester' : 'Direct Navigation',
    ipAddress: finalScore >= 75 ? '185.220.101.' + Math.floor(10 + Math.random() * 80) : '104.21.44.18',
    serverCountry: finalScore >= 75 ? 'Russia (RU)' : 'United States (US)',
    domainAgeDays: finalScore >= 75 ? Math.floor(1 + Math.random() * 5) : 3400,
    sslValid: finalScore < 85,
    sslIssuer: finalScore >= 75 ? "Let's Encrypt Free DV" : 'Google Trust Services / DigiCert',
    lexicalFlags: lexicalFlags.length > 0 ? lexicalFlags : ['Clean URI syntax', 'Standard subdomain hierarchy', 'Known TLD'],
    heuristicReasons,
    status,
    timestamp: 'Just now'
  };
}
