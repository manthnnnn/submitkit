'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  AlertCircle, CheckCircle2, XCircle, FileText, Clock, DollarSign, 
  Search, ShieldAlert, ArrowRight 
} from 'lucide-react';
import { INITIAL_DISPUTES, Dispute } from '@/lib/fraud-data';

export default function DisputesPage() {
  const [disputes, setDisputes] = useState<Dispute[]>(INITIAL_DISPUTES);
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const handleUpdateStatus = (id: string, newStatus: Dispute['status']) => {
    setDisputes(prev => prev.map(d => d.id === id ? { ...d, status: newStatus } : d));
  };

  const filtered = disputes.filter(d => filterStatus === 'ALL' || d.status === filterStatus);

  return (
    <div style={{ maxWidth: '1440px', margin: '0 auto', padding: '24px 16px' }}>
      {/* Header */}
      <div style={{ marginBottom: '28px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
          <span style={{
            padding: '3px 10px',
            borderRadius: '999px',
            fontSize: '0.7rem',
            fontWeight: 700,
            background: 'rgba(56, 189, 248, 0.15)',
            color: 'var(--accent-cyan)',
            border: '1px solid rgba(56, 189, 248, 0.3)',
            textTransform: 'uppercase',
          }}>
            Resolution Portal
          </span>
          <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            Chargeback &amp; Dispute Management
          </span>
        </div>
        <h1 style={{ fontSize: '1.95rem', fontWeight: 800, letterSpacing: '-0.03em', color: '#ffffff', lineHeight: 1.2 }}>
          Customer Chargeback &amp; Dispute Resolution Desk
        </h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginTop: '4px', maxWidth: '750px' }}>
          Triage cardholder claim disputes, examine transactional forensic evidence, execute direct merchant reversals, and issue cardholder chargeback refunds.
        </p>
      </div>

      {/* Filter Tabs */}
      <div style={{ display: 'flex', gap: '6px', marginBottom: '20px', flexWrap: 'wrap' }}>
        {['ALL', 'PENDING_REVIEW', 'EVIDENCE_REQUIRED', 'REFUNDED', 'DISMISSED'].map((st) => (
          <button
            key={st}
            onClick={() => setFilterStatus(st)}
            style={{
              padding: '6px 14px',
              borderRadius: '6px',
              fontSize: '0.76rem',
              fontWeight: 700,
              cursor: 'pointer',
              border: 'none',
              background: filterStatus === st ? 'var(--accent-cyan)' : 'rgba(255, 255, 255, 0.04)',
              color: filterStatus === st ? '#07090e' : 'var(--text-secondary)',
              transition: 'all 0.15s ease',
            }}
          >
            {st.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Disputes Cards List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
        {filtered.map((disp) => {
          let badgeColor = 'var(--accent-amber)';
          let badgeBg = 'rgba(245, 158, 11, 0.12)';
          if (disp.status === 'REFUNDED') {
            badgeColor = 'var(--accent-emerald)';
            badgeBg = 'rgba(16, 185, 129, 0.12)';
          } else if (disp.status === 'DISMISSED') {
            badgeColor = 'var(--accent-rose)';
            badgeBg = 'rgba(244, 63, 94, 0.12)';
          }

          return (
            <div
              key={disp.id}
              className="glass-panel"
              style={{
                padding: '20px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-start',
                flexWrap: 'wrap',
                gap: '16px',
              }}
            >
              <div style={{ flex: 1, minWidth: '280px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
                  <span style={{
                    fontSize: '0.68rem',
                    fontWeight: 700,
                    padding: '2px 7px',
                    borderRadius: '4px',
                    background: badgeBg,
                    color: badgeColor,
                    textTransform: 'uppercase',
                  }}>
                    {disp.status.replace('_', ' ')}
                  </span>
                  <span style={{ fontSize: '0.74rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                    {disp.id} • Ref: {disp.transactionId}
                  </span>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                    Filed: {disp.filedDate}
                  </span>
                </div>

                <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#ffffff' }}>
                  {disp.cardholder} ➔ {disp.merchant}
                </h3>

                <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.5, background: 'rgba(0,0,0,0.2)', padding: '8px 12px', borderRadius: '6px' }}>
                  <strong>Cardholder Statement:</strong> &quot;{disp.reason}&quot;
                </p>
              </div>

              {/* Amount & Quick Actions */}
              <div style={{ textAlign: 'right', display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '10px' }}>
                <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#ffffff', fontFamily: 'var(--font-mono)' }}>
                  ${disp.amount.toFixed(2)} USD
                </div>

                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => handleUpdateStatus(disp.id, 'REFUNDED')}
                    disabled={disp.status === 'REFUNDED'}
                    style={{
                      padding: '6px 12px',
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      fontWeight: 700,
                      cursor: 'pointer',
                      border: 'none',
                      background: 'rgba(16, 185, 129, 0.15)',
                      color: 'var(--accent-emerald)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'rgba(16, 185, 129, 0.35)',
                    }}
                  >
                    Approve Refund
                  </button>

                  <button
                    onClick={() => handleUpdateStatus(disp.id, 'DISMISSED')}
                    disabled={disp.status === 'DISMISSED'}
                    style={{
                      padding: '6px 12px',
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      fontWeight: 700,
                      cursor: 'pointer',
                      border: 'none',
                      background: 'rgba(244, 63, 94, 0.15)',
                      color: 'var(--accent-rose)',
                      borderWidth: '1px',
                      borderStyle: 'solid',
                      borderColor: 'rgba(244, 63, 94, 0.35)',
                    }}
                  >
                    Dismiss Dispute
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
