import { Transaction } from './fraud-data';

const RANDOM_NAMES = ['Alexander Reed', 'Sophia Martinez', 'Liam O\'Connor', 'Fatima Al-Sayed', 'Kenji Sato', 'Emma Watson', 'Carlos Gomez'];
const RANDOM_MERCHANTS: { name: string; category: Transaction['category']; baseRisk: number }[] = [
  { name: 'Uber Technologies', category: 'Travel & Flights', baseRisk: 8 },
  { name: 'Rolex Boutique Geneva', category: 'Luxury Goods', baseRisk: 75 },
  { name: 'Binance P2P Crypto', category: 'Crypto Exchange', baseRisk: 85 },
  { name: 'Best Buy Electronics', category: 'Electronics', baseRisk: 35 },
  { name: 'Starbucks Coffee', category: 'Dining', baseRisk: 4 },
  { name: 'Target Supercenter', category: 'Grocery', baseRisk: 10 },
  { name: 'Singapore Airlines', category: 'Travel & Flights', baseRisk: 45 }
];

const RANDOM_CITIES: { city: string; country: string }[] = [
  { city: 'New York, NY', country: 'US' },
  { city: 'London', country: 'GB' },
  { city: 'Tokyo', country: 'JP' },
  { city: 'Berlin', country: 'DE' },
  { city: 'Sao Paulo', country: 'BR' },
  { city: 'Dubai', country: 'AE' }
];

export function generateRandomTransaction(): Transaction {
  const name = RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)];
  const merchantObj = RANDOM_MERCHANTS[Math.floor(Math.random() * RANDOM_MERCHANTS.length)];
  const locationObj = RANDOM_CITIES[Math.floor(Math.random() * RANDOM_CITIES.length)];
  
  // Random amount between $10 and $4,500
  const isHighValue = Math.random() > 0.75;
  const amount = isHighValue 
    ? Math.round(1200 + Math.random() * 3200) 
    : Math.round(15 + Math.random() * 180);

  // Anomaly calculation
  const triggers: string[] = [];
  let riskScore = merchantObj.baseRisk + Math.floor(Math.random() * 15);

  if (amount > 2000) {
    riskScore += 25;
    triggers.push(`High Transaction Amount ($${amount.toLocaleString()})`);
  }

  if (Math.random() > 0.8) {
    riskScore += 30;
    triggers.push('Impossible Velocity (>800 mi/hr)');
  }

  if (Math.random() > 0.85) {
    riskScore += 20;
    triggers.push('New Untrusted Device / Tor Node');
  }

  riskScore = Math.min(99, Math.max(2, riskScore));

  let riskLevel: Transaction['riskLevel'] = 'LOW';
  let status: Transaction['status'] = 'APPROVED';

  if (riskScore >= 75) {
    riskLevel = 'CRITICAL_FRAUD';
    status = 'BLOCKED';
  } else if (riskScore >= 45) {
    riskLevel = 'MEDIUM';
    status = 'CHALLENGED_3DS';
  }

  return {
    id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
    cardLast4: String(Math.floor(1000 + Math.random() * 9000)),
    cardholderName: name,
    amount,
    currency: 'USD',
    merchant: merchantObj.name,
    category: merchantObj.category,
    location: locationObj.city,
    country: locationObj.country,
    ipAddress: `${Math.floor(50 + Math.random() * 150)}.${Math.floor(10 + Math.random() * 200)}.${Math.floor(1 + Math.random() * 250)}.${Math.floor(1 + Math.random() * 250)}`,
    device: Math.random() > 0.5 ? 'iPhone Safari Mobile' : 'Windows Chrome Desktop',
    timestamp: 'Just now',
    riskScore,
    riskLevel,
    status,
    triggers
  };
}
