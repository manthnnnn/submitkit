================================================================================
       LIFEDROP: SMART BLOOD BANK MANAGEMENT & DISPATCH SYSTEM
       Academic Project Bundle | Verified Production-Ready Build
================================================================================

Congratulations on downloading your project bundle! This project is pre-configured
for zero-friction execution and academic presentation.

--------------------------------------------------------------------------------
1. QUICK START (1-CLICK LAUNCHER)
--------------------------------------------------------------------------------
- Windows Users:
  Double-click the `run.bat` file in this directory.
  The launcher will:
  1. Verify your Node.js runtime.
  2. Install all required dependencies automatically.
  3. Push the Prisma database schema to the local SQLite engine (`prisma/dev.db`).
  4. Launch your default web browser to http://localhost:3000.
  5. Start the Next.js development server.

- Mac / Linux Users:
  Open a terminal in this folder and run:
    npm install
    npx prisma db push
    node prisma/seed.js
    npm run dev
  Then open http://localhost:3000 in your browser.

* Note: Node.js (v18 or higher) must be installed. If not, download from https://nodejs.org

--------------------------------------------------------------------------------
2. PROJECT FEATURES & PAGES WALKTHROUGH
--------------------------------------------------------------------------------
1. Dashboard (/)
   - Real-time stock telemetry across all 8 blood groups (A+, A-, B+, B-, AB+, AB-, O+, O-).
   - Live KPI counters (Total Units, Active Donors, Urgent Requisitions, Fulfilled Cases).
   - Quick-access queues for urgent patient requisitions and recent donors.

2. Donor Directory (/donors)
   - Searchable, filterable list of voluntary donors.
   - Clinical 90-day cooldown period algorithm indicator (Eligible vs Cooldown).
   - "Log Donation" and "Delete Donor" actions.

3. Emergency Requisitions & Compatibility Matcher (/requests)
   - Live triage queue categorized by urgency (Critical, Urgent, Standard).
   - Biological Transfusion Compatibility Engine (enforces ABO & Rh factor rules).
   - One-click "Mark as Fulfilled" workflow.

4. Stock Analytics (/inventory)
   - Interactive Recharts bar graph & distribution pie chart.
   - Critical deficit alerts (< 2 units remaining).
   - Clinical transfusion compatibility reference matrix table.

5. Donor Registration Portal (/donors/new)
   - Fast registration form for voluntary blood donors.

6. Emergency Blood Request (/requests/new)
   - Hospital ICU requisition broadcast form.

--------------------------------------------------------------------------------
3. ACADEMIC DOCUMENTATION INCLUDED
--------------------------------------------------------------------------------
- `IEEE_Report.md`:
  A comprehensive 10-chapter academic report strictly following IEEE formatting.
  Includes Abstract, Problem Statement, SRS, System Architecture, ER Model,
  Biological Algorithms, Software Test Cases, and References.
  -> Copy-paste directly into Microsoft Word to print your college Black Book!

- `Viva_Presentation_Notes.md`:
  Complete 15-slide defense presentation structure with word-for-word speaker notes,
  plus the "Top 20 Viva Questions Asked by External Examiners with Model Answers".

Best of luck with your college project presentation and viva evaluation!
================================================================================
