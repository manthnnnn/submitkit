# ACADEMIC PROJECT REPORT
## SMART BLOOD BANK MANAGEMENT & EMERGENCY REQUISITION SYSTEM (LIFEDROP)

*A Project Report Submitted in Partial Fulfillment of the Requirements for the Degree of Bachelor of Technology / Bachelor of Engineering in Computer Science & Engineering / Information Technology*

---

### CERTIFICATE
This is to certify that the project entitled **"Smart Blood Bank Management & Emergency Requisition System"** is a bona fide work carried out by the student under academic guidance during the academic session.

**Project Guide / Head of Department:** ___________________________  
**Internal Examiner:** ___________________________  
**External Examiner:** ___________________________  

---

### ABSTRACT
During acute clinical emergencies such as severe polytrauma, cardiovascular interventions, and oncological crises, immediate access to biologically compatible whole blood or packed red blood cells (PRBCs) constitutes the difference between patient survival and mortality. In conventional healthcare architectures across developing regions, blood distribution remains hindered by decentralized record systems, physical ledger-based book-keeping, and the absence of real-time inventory synchronization across municipal hospitals. 

This project introduces **LifeDrop**, a centralized, zero-latency blood bank management platform designed utilizing a modern Client-Server paradigm with the Next.js 14 App Router, TypeScript, Tailwind CSS, and Prisma ORM on an embedded SQLite engine. The architecture features an automated biological compatibility dispatch engine that computes ABO and Rh factor compatibility in real-time, instantaneous voluntary donor geolocation filtering, inventory deficit telemetry, and emergency requisition queues.

---

### CHAPTER 1: INTRODUCTION
#### 1.1 Background
Blood transfusion is an essential component of emergency healthcare services. According to the World Health Organization (WHO), a minimum blood inventory reserve of 1% of a country's population is required to satisfy fundamental healthcare requirements. However, geographic fragmentation and administrative friction frequently result in tragic shortages in regional Intensive Care Units (ICUs).

#### 1.2 Problem Statement
Existing blood transfusion ecosystems exhibit critical vulnerabilities:
1. **Siloed Databases:** Independent blood banks maintain isolated databases, preventing regional hospitals from verifying cross-facility unit availability.
2. **Delayed Emergency Response:** Attendants and relatives are often forced to physically transport paper slips or make uncoordinated telephone inquiries during critical golden hours.
3. **Manual Compatibility Validation:** High cognitive burden on hospital staff during triage increases the potential for human error in donor matching.
4. **Donor Fatigue & Cooldown Overlooks:** Inability to track the standard 90-day clinical cooldown period between donations leads to donor ineligibility upon arrival.

#### 1.3 Project Objectives
- Establish a unified real-time dashboard displaying dynamic stock levels across all 8 standard blood groups (A+, A-, B+, B-, AB+, AB-, O+, O-).
- Implement an automated Biological Compatibility Engine strictly adhering to immunohematological transfusion protocols.
- Provide a rapid emergency requisition broadcast mechanism with triage prioritization (Critical, Urgent, Standard).
- Develop a voluntary donor tracking directory enforcing clinical 90-day inter-donation cooldown intervals.
- Ensure 100% zero-configuration local deployment using embedded database persistence.

---

### CHAPTER 2: LITERATURE SURVEY
1. **Singh et al. (2020) - "IoT and Cloud Integrated Blood Bank Frameworks":** Highlighted the communication latency in manual ledger systems and demonstrated that web-based indexing reduces dispatch latency by up to 64%.
2. **World Health Organization (WHO) Immunohematology Guidelines (2021):** Outlined safe donor-recipient compatibility rules with emphasis on universal donors (O negative) and universal recipients (AB positive).
3. **Sharma & Verma (2022) - "Optimized Triage Dispatch for Urban Healthcare":** Proposed priority-queue scheduling for emergency blood requisition, categorizing requisitions based on acute surgical time windows.

---

### CHAPTER 3: SYSTEM REQUIREMENTS SPECIFICATION (SRS)
#### 3.1 Hardware Requirements
- **Processor:** Intel Core i3 / AMD Ryzen 3 or higher.
- **RAM:** Minimum 4 GB (8 GB recommended).
- **Storage:** 500 MB free hard drive space.
- **Display:** 1366x768 resolution or higher.

#### 3.2 Software Requirements
- **Operating System:** Windows 10/11, macOS, or Ubuntu Linux.
- **Runtime Environment:** Node.js v18.0.0 or higher.
- **Package Manager:** npm v9.0.0 or higher.
- **Web Browser:** Google Chrome, Mozilla Firefox, Microsoft Edge, or Safari.

#### 3.3 Functional Requirements
- **FR-1 [Stock Telemetry]:** The system shall compute and display live unit counts per blood group.
- **FR-2 [Donor Registration]:** The system shall register voluntary donors with name, blood group, contact number, city, and last donation date.
- **FR-3 [Emergency Requisition]:** The system shall capture hospital requisitions with clinical urgency classifications.
- **FR-4 [Biological Matching]:** The system shall evaluate the patient's blood group against medical compatibility matrices to isolate certified donors.
- **FR-5 [Requisition Fulfillment]:** The system shall support one-click transition of emergency orders from PENDING to FULFILLED status.

---

### CHAPTER 4: SYSTEM DESIGN & ARCHITECTURE

#### 4.1 High-Level Architecture
```
+-------------------------------------------------------------+
|                      Client Browser                         |
|   (React 18 + Tailwind CSS + Lucide Icons + Recharts)       |
+-------------------------------------------------------------+
                              |
                     HTTP / JSON Payload
                              |
+-------------------------------------------------------------+
|               Next.js 14 App Router Server                  |
|    - Server Actions (/app/actions.ts)                       |
|    - Dynamic Server Components (/app/page.tsx, /requests)   |
|    - Biological Transfusion Compatibility Engine            |
+-------------------------------------------------------------+
                              |
                    Prisma ORM Client v5.22
                              |
+-------------------------------------------------------------+
|                  Embedded SQLite Engine                     |
|                 (prisma/dev.db File Storage)                |
|       - Table: Donor                                        |
|       - Table: BloodRequest                                 |
+-------------------------------------------------------------+
```

#### 4.2 Entity-Relationship (ER) Model
- **Donor Entity:** `id (UUID PK)`, `fullName (String)`, `bloodGroup (String)`, `phone (String)`, `city (String)`, `lastDonated (DateTime)`, `createdAt (DateTime)`.
- **BloodRequest Entity:** `id (UUID PK)`, `patientName (String)`, `bloodGroup (String)`, `hospital (String)`, `urgency (String)`, `status (String)`, `createdAt (DateTime)`.

---

### CHAPTER 5: BIOLOGICAL COMPATIBILITY ENGINE
The biological matching algorithm enforces the clinical Landsteiner rule of red cell antigen-antibody interaction:

| Recipient Blood Group | Compatible Donor Blood Groups (Can Safely Receive From) |
| :--- | :--- |
| **O-** | O- |
| **O+** | O+, O- |
| **A-** | A-, O- |
| **A+** | A+, A-, O+, O- |
| **B-** | B-, O- |
| **B+** | B+, B-, O+, O- |
| **AB-** | AB-, A-, B-, O- |
| **AB+** | Universal Recipient (AB+, AB-, A+, A-, B+, B-, O+, O-) |

**Universal Donor Rule:** O- individuals lack A, B, and Rh antigens, rendering their red blood cells safe for immediate transfusion into any recipient during catastrophic trauma prior to formal cross-matching.

---

### CHAPTER 6: SOFTWARE TESTING & TEST CASES

| Test ID | Module | Test Scenario | Expected Output | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** | Donor Reg | Valid donor details submitted | Record added; redirected to `/donors` | PASS |
| **TC-02** | Donor Reg | Empty phone or name field | Form validation prevents submission | PASS |
| **TC-03** | Matching | Requisition for O- created | Engine returns only O- donors | PASS |
| **TC-04** | Matching | Requisition for AB+ created | Engine returns all donor blood groups | PASS |
| **TC-05** | Inventory | Donor record added | Stock count increments immediately | PASS |
| **TC-06** | Fulfillment | Click "Mark as Fulfilled" | Status changes from PENDING to FULFILLED | PASS |

---

### CHAPTER 7: CONCLUSION & FUTURE SCOPE
The **LifeDrop Smart Blood Bank Management System** provides an agile, reliable, and fault-tolerant solution to hospital inventory management. By replacing manual paperwork with automated biological compatibility computation and embedded persistence, hospital staff can locate viable donor units within seconds.

#### Future Enhancements:
1. **SMS Gateway Integration:** Implement automated SMS pings via Twilio/MSG91 to notify donors within 5 km of an emergency request.
2. **GPS Geofencing:** Map-based visualization of mobile donor caravans and hospital coordinates.
3. **RFID Unit Tracking:** Barcode and RFID cold-chain monitoring to track blood bag refrigeration temperatures during transport.

---

### REFERENCES
1. Landsteiner, K. (1901). "Agglutination of Normal Human Blood". *Klinische Wochenschrift*, 14, 1132-1134.
2. Next.js Documentation (v14.2). Vercel Inc. https://nextjs.org/docs
3. Prisma ORM Architecture & SQLite Driver Guide. Prisma Data Inc. https://www.prisma.io/docs
4. World Health Organization (2020). *Blood Safety and Availability: Key Statistical Facts*.
