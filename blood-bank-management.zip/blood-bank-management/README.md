# LifeDrop — Smart Blood Bank Management System

> **A Production-Grade, Full-Stack Hospital Blood Bank & Transfusion Logistics Platform**  
> Built with Next.js 14 (App Router), TypeScript, Tailwind CSS, Prisma ORM, and SQLite.

---

## 🌟 Key Features

1. **Intuitive 4-Step Clinical Workflow**:
   - `01. Register Donor`: Instant onboarding with demographic, contact, and blood group validation.
   - `02. Collect Blood Bag`: Log 450ml donations, assign cold storage racks, track 42-day expiration dates, and award **Gold-Bordered Certificates of Appreciation**.
   - `03. Hospital ICU Order`: Emergency hospital broadcast with urgency categorization (Critical, Urgent, Standard).
   - `04. Dispense & Handover Slip`: Automatic biological compatibility matching (ABO/Rh Landsteiner rules), stock deduction, and printable **Official Blood Handover Receipt**.

2. **Cold-Vault Inventory Telemetry**:
   - Real-time stock counters across all 8 blood groups (A+, A-, B+, B-, AB+, AB-, O+, O-).
   - Interactive Recharts Bar and Donut Distribution charts.
   - Serialized Blood Bag ledger tracking rack location, donation date, and expiration status.

3. **Academic Deliverables Included**:
   - Complete 10-Chapter IEEE Standard Project Report (`IEEE_Report.md`).
   - Viva Voce Defense Guide & Top 20 Examination Questions with Answers (`Viva_Presentation_Notes.md`).
   - 1-Click launcher script (`run.bat`).

---

## 📸 Screenshots & Visual Tour

### 1. Executive Dashboard & 4-Step Workflow Banner
![Dashboard](screenshots/01_dashboard.jpg)

### 2. Donor Directory & 90-Day Medical Cooldown Tracker
![Donors Directory](screenshots/02_donors_directory.jpg)

### 3. Printable Donor Appreciation Certificate Modal
![Donor Certificate](screenshots/03_donor_certificate.jpg)

### 4. Serialized Blood Bag Collection Modal
![Collect Blood Unit](screenshots/04_collect_blood_modal.jpg)

### 5. Emergency ICU Requisitions & Biological Compatibility Matcher
![Emergency Requests](screenshots/05_emergency_requests.jpg)

### 6. Official Blood Handover Receipt & Dispense Slip
![Handover Slip](screenshots/06_blood_handover_slip.jpg)

### 7. Cold Vault Inventory & Telemetry Analytics
![Inventory Telemetry](screenshots/07_cold_vault_inventory.jpg)

### 8. Donor Onboarding Form
![Donor Registration](screenshots/08_new_donor_registration.jpg)

### 9. Hospital Emergency Requisition Broadcast
![Hospital Request](screenshots/09_new_emergency_request.jpg)

---

## 🚀 Quick Start (1-Click Run)

### Windows
Double-click **`run.bat`** in this folder. It will:
1. Verify your Node.js runtime.
2. Install npm dependencies automatically.
3. Push the SQLite database schema and seed sample data.
4. Launch the application and open your browser at `http://localhost:3000`.

### Manual Start
```bash
npm install
npx prisma db push
node prisma/seed.js
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 📂 Project Architecture
```
blood-bank-management/
├── IEEE_Report.md              # Complete 10-chapter academic project report
├── Viva_Presentation_Notes.md  # 15-slide defense notes & Top 20 Viva Q&A
├── README_FIRST.txt            # Quick setup guide for students
├── run.bat                     # 1-click zero-configuration launcher
├── screenshots/                # High-resolution screenshots of all workflows
├── prisma/
│   ├── schema.prisma           # SQLite relational data schema
│   ├── seed.js                 # Realistic seed data (donors, bags, requests)
│   └── dev.db                  # Embedded zero-config SQLite database
└── src/
    ├── app/                    # Next.js App Router (pages & server actions)
    ├── components/             # Reusable UI components & print modals
    └── lib/                    # Database client & utility functions
```
