import Link from 'next/link';
import { Droplet, Heart, LayoutDashboard, PlusCircle, BarChart3, AlertCircle, Users } from 'lucide-react';

export function Navbar() {
  return (
    <nav className="border-b bg-white/95 backdrop-blur-md shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-md shadow-red-600/20">
                <Droplet className="h-6 w-6 fill-white text-white" />
              </div>
              <div className="flex flex-col">
                <span className="font-black text-xl text-gray-900 tracking-tight leading-tight">LifeDrop</span>
                <span className="text-[10px] font-bold text-red-600 uppercase tracking-wider">Smart Blood Bank</span>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <div className="hidden md:flex items-center gap-1">
              <Link 
                href="/" 
                className="text-gray-600 hover:text-red-600 px-3 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <LayoutDashboard className="h-4 w-4" />
                <span>Dashboard</span>
              </Link>

              <Link 
                href="/donors" 
                className="text-gray-600 hover:text-red-600 px-3 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <Users className="h-4 w-4" />
                <span>Donors</span>
              </Link>

              <Link 
                href="/requests" 
                className="text-gray-600 hover:text-red-600 px-3 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <AlertCircle className="h-4 w-4" />
                <span>Emergency Requisitions</span>
              </Link>

              <Link 
                href="/inventory" 
                className="text-gray-600 hover:text-red-600 px-3 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <BarChart3 className="h-4 w-4" />
                <span>Stock & Analytics</span>
              </Link>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3">
            <Link 
              href="/donors/new" 
              className="text-gray-700 hover:text-red-600 hover:bg-red-50 border border-gray-200 px-3.5 py-2 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all"
            >
              <Heart className="h-3.5 w-3.5 text-red-600" />
              <span className="hidden sm:inline">Register Donor</span>
            </Link>
            <Link 
              href="/requests/new" 
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-xl flex items-center gap-1.5 text-xs font-bold transition-all shadow-sm hover:shadow-md"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              <span>Request Blood</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
