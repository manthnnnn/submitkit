'use client';

import { Award, Printer, X, FileText, CheckCircle2 } from 'lucide-react';

export function DonorCertificateModal({ 
  donor, 
  onClose 
}: { 
  donor: { fullName: string; bloodGroup: string; city: string; totalDonations: number }; 
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-8 shadow-2xl relative border-8 border-red-50 text-center">
        <button 
          onClick={onClose}
          className="absolute right-4 top-4 p-2 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Certificate Header */}
        <div className="flex items-center justify-center gap-2 mb-2">
          <Award className="w-12 h-12 text-amber-500" />
        </div>
        <span className="text-[10px] font-black uppercase tracking-widest text-red-600 bg-red-50 px-3 py-1 rounded-full">
          Official Recognition of Life-Saving Service
        </span>
        <h2 className="text-3xl font-serif font-black text-gray-900 mt-4">Certificate of Appreciation</h2>
        <p className="text-xs text-gray-400 font-serif italic mt-1">LifeDrop National Voluntary Blood Donation Network</p>

        {/* Certificate Body */}
        <div className="my-8 py-6 border-y-2 border-dashed border-amber-200 space-y-3">
          <p className="text-sm text-gray-600">This certificate is proudly presented to:</p>
          <h3 className="text-2xl font-black text-red-700 tracking-wide uppercase">{donor.fullName}</h3>
          <p className="text-xs text-gray-600 max-w-md mx-auto leading-relaxed">
            In grateful recognition of your voluntary donation of <strong className="text-gray-900 font-bold">Blood Group {donor.bloodGroup}</strong> in {donor.city}. Your selfless act of compassion empowers emergency Intensive Care Units and directly saves human lives.
          </p>
          <div className="inline-block bg-amber-50 text-amber-800 font-bold text-xs px-4 py-1.5 rounded-full border border-amber-200 mt-2">
            Milestone: {donor.totalDonations} Lifetime Blood Donations Recorded
          </div>
        </div>

        {/* Signatures */}
        <div className="grid grid-cols-2 gap-8 text-left text-xs text-gray-500 pt-2">
          <div className="border-t border-gray-300 pt-2 text-center">
            <p className="font-bold text-gray-800">Dr. V. K. Ramanathan</p>
            <p className="text-[10px]">Medical Director, LifeDrop Central Bank</p>
          </div>
          <div className="border-t border-gray-300 pt-2 text-center">
            <p className="font-bold text-gray-800">{new Date().toLocaleDateString('en-GB')}</p>
            <p className="text-[10px]">Date of Certification</p>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-8 flex justify-center gap-3">
          <button
            onClick={() => window.print()}
            className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow-md flex items-center gap-2 transition-all"
          >
            <Printer className="w-4 h-4" /> Print / Save Certificate PDF
          </button>
        </div>
      </div>
    </div>
  );
}

export function BloodIssueReceiptModal({
  request,
  onClose
}: {
  request: {
    requestCode: string;
    patientName: string;
    bloodGroup: string;
    hospital: string;
    doctorName: string;
    dispensedBagCodes?: string | null;
    dispensedAt?: Date | null;
  };
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative border border-gray-200">
        <button 
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 border-b border-gray-100 pb-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900 text-base">Official Blood Handover Receipt</h3>
            <p className="text-xs text-gray-400">Requisition Code: {request.requestCode}</p>
          </div>
        </div>

        <div className="space-y-3.5 my-5 text-xs text-gray-700">
          <div className="flex justify-between py-1.5 border-b border-gray-50">
            <span className="text-gray-400">Patient Name:</span>
            <span className="font-bold text-gray-900">{request.patientName}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-gray-50">
            <span className="text-gray-400">Transfusion Blood Group:</span>
            <span className="font-black text-red-600 text-sm">{request.bloodGroup}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-gray-50">
            <span className="text-gray-400">Hospital Facility:</span>
            <span className="font-medium text-gray-800">{request.hospital}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-gray-50">
            <span className="text-gray-400">Attending Physician:</span>
            <span className="font-medium text-gray-800">{request.doctorName}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-gray-50">
            <span className="text-gray-400">Dispensed Bag Serial Number:</span>
            <span className="font-mono font-bold bg-gray-100 text-gray-900 px-2 py-0.5 rounded">
              {request.dispensedBagCodes || 'BAG-VERIFIED-1001'}
            </span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-gray-50">
            <span className="text-gray-400">Dispense Timestamp:</span>
            <span className="font-medium text-gray-800">
              {request.dispensedAt ? new Date(request.dispensedAt).toLocaleString('en-GB') : new Date().toLocaleString('en-GB')}
            </span>
          </div>
        </div>

        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-2 text-emerald-800 text-xs font-semibold">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Cross-match verified & Cold-chain seal intact.</span>
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <button
            onClick={() => window.print()}
            className="w-full bg-gray-900 hover:bg-black text-white font-bold text-xs py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4" /> Print Handover Receipt
          </button>
        </div>
      </div>
    </div>
  );
}
