import { prisma } from '@/lib/prisma';
import { InventoryCharts } from './InventoryCharts';
import { ShieldAlert, CheckCircle2, AlertTriangle, Droplet, Package } from 'lucide-react';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function InventoryPage() {
  const bloodBags = await prisma.bloodBag.findMany({ 
    orderBy: { collectedAt: 'desc' } 
  });

  const availableBags = bloodBags.filter(b => b.status === 'AVAILABLE');
  const dispensedBags = bloodBags.filter(b => b.status === 'DISPENSED');

  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const inventory = bloodGroups.map(bg => ({
    group: bg,
    count: availableBags.filter(b => b.bloodGroup === bg).length
  }));

  const criticalShortages = inventory.filter(i => i.count < 2);

  const compatibilityMatrix = [
    { type: 'O-', canGive: 'Everyone (Universal Donor)', canReceive: 'O-' },
    { type: 'O+', canGive: 'O+, A+, B+, AB+', canReceive: 'O+, O-' },
    { type: 'A-', canGive: 'A-, A+, AB-, AB+', canReceive: 'A-, O-' },
    { type: 'A+', canGive: 'A+, AB+', canReceive: 'A+, A-, O+, O-' },
    { type: 'B-', canGive: 'B-, B+, AB-, AB+', canReceive: 'B-, O-' },
    { type: 'B+', canGive: 'B+, AB+', canReceive: 'B+, B-, O+, O-' },
    { type: 'AB-', canGive: 'AB-, AB+', canReceive: 'AB-, A-, B-, O-' },
    { type: 'AB+', canGive: 'AB+ Only', canReceive: 'Everyone (Universal Recipient)' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight">Cold-Chain Blood Inventory</h1>
          <p className="text-gray-500 text-sm mt-1">Real-time inventory levels, serialized blood bags, and cold-storage management.</p>
        </div>
        <Link 
          href="/donors" 
          className="inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold shadow-sm transition-all"
        >
          <Droplet className="w-4 h-4" />
          <span>Collect Blood from Donor</span>
        </Link>
      </div>

      {/* Warning Banners */}
      {criticalShortages.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4 flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div className="text-xs text-red-900">
            <span className="font-bold">Critical Shortage Alert:</span> The following blood groups have less than 2 units in stock:
            <div className="flex flex-wrap gap-1.5 mt-2">
              {criticalShortages.map(s => (
                <span key={s.group} className="bg-red-600 text-white font-black px-2 py-0.5 rounded-md text-xs">
                  {s.group} ({s.count} left)
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Analytics Charts */}
      <InventoryCharts inventoryData={inventory} />

      {/* Serialized Blood Bags in Vault */}
      <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-gray-900 text-base flex items-center gap-2">
              <Package className="w-5 h-5 text-red-600" />
              Serialized Blood Units in Vault ({availableBags.length} Available)
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">Individual blood bags currently stored in temperature-controlled racks.</p>
          </div>
          <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full">
            {dispensedBags.length} Units Dispensed
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-gray-100 text-gray-400 uppercase tracking-wider font-semibold">
                <th className="pb-3">Bag Serial Code</th>
                <th className="pb-3">Blood Group</th>
                <th className="pb-3">Donor Name</th>
                <th className="pb-3">Vault Location</th>
                <th className="pb-3">Collection Date</th>
                <th className="pb-3">Expiration Date</th>
                <th className="pb-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 font-medium">
              {bloodBags.slice(0, 10).map(bag => (
                <tr key={bag.id} className="hover:bg-gray-50/50">
                  <td className="py-3 font-mono font-bold text-gray-900 text-xs">{bag.bagCode}</td>
                  <td className="py-3 font-black text-red-600">{bag.bloodGroup}</td>
                  <td className="py-3 text-gray-700">{bag.donorName || 'Voluntary Donor'}</td>
                  <td className="py-3 text-gray-500 font-mono text-[11px]">{bag.storageRack}</td>
                  <td className="py-3 text-gray-500">{new Date(bag.collectedAt).toLocaleDateString('en-GB')}</td>
                  <td className="py-3 text-gray-700 font-semibold">{new Date(bag.expiresAt).toLocaleDateString('en-GB')}</td>
                  <td className="py-3">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      bag.status === 'AVAILABLE' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {bag.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stock Safety Thresholds Table */}
      <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm">
        <h3 className="font-bold text-gray-900 text-base mb-4">Stock Safety Thresholds</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-gray-100 text-gray-400 uppercase tracking-wider font-semibold">
                <th className="pb-3">Blood Group</th>
                <th className="pb-3">Available Bags</th>
                <th className="pb-3">Safety Status</th>
                <th className="pb-3">Action Recommended</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 font-medium">
              {inventory.map(item => {
                let statusBadge = (
                  <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full text-[11px] font-bold">
                    <CheckCircle2 className="w-3 h-3" /> Healthy Stock
                  </span>
                );
                let recommendation = 'Standard operational rotation.';

                if (item.count < 2) {
                  statusBadge = (
                    <span className="inline-flex items-center gap-1 text-red-700 bg-red-50 px-2.5 py-1 rounded-full text-[11px] font-bold">
                      <ShieldAlert className="w-3 h-3" /> Critical Deficit
                    </span>
                  );
                  recommendation = 'Launch urgent donor camp and broadcast emergency alerts.';
                } else if (item.count < 4) {
                  statusBadge = (
                    <span className="inline-flex items-center gap-1 text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full text-[11px] font-bold">
                      <AlertTriangle className="w-3 h-3" /> Moderate Stock
                    </span>
                  );
                  recommendation = 'Reach out to voluntary donors on cooldown expiry.';
                }

                return (
                  <tr key={item.group} className="hover:bg-gray-50/50">
                    <td className="py-3 font-bold text-gray-900 text-sm">
                      <span className="inline-block w-8 h-8 rounded-lg bg-red-50 text-red-600 text-center leading-8 font-black mr-2">
                        {item.group}
                      </span>
                    </td>
                    <td className="py-3 text-gray-700 font-bold text-sm">{item.count} Units</td>
                    <td className="py-3">{statusBadge}</td>
                    <td className="py-3 text-gray-500">{recommendation}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Biological Compatibility Matrix Reference */}
      <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm">
        <h3 className="font-bold text-gray-900 text-base mb-2">Clinical Transfusion Reference Matrix</h3>
        <p className="text-xs text-gray-500 mb-6">Standard ABO & Rh factor compatibility guidelines implemented in LifeDrop.</p>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-gray-100 text-gray-400 uppercase tracking-wider font-semibold">
                <th className="pb-3">Recipient Type</th>
                <th className="pb-3">Can Receive From (Donors)</th>
                <th className="pb-3">Can Donate To (Recipients)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 font-medium">
              {compatibilityMatrix.map(row => (
                <tr key={row.type} className="hover:bg-gray-50/50">
                  <td className="py-3 font-bold text-red-600 text-sm">{row.type}</td>
                  <td className="py-3 text-gray-800 font-semibold">{row.canReceive}</td>
                  <td className="py-3 text-gray-600">{row.canGive}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
