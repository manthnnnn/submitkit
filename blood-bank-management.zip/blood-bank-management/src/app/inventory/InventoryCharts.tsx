'use client';

import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Cell, 
  PieChart, 
  Pie, 
  Legend 
} from 'recharts';

const COLORS = ['#ef4444', '#f97316', '#f59e0b', '#10b981', '#06b6d4', '#3b82f6', '#8b5cf6', '#ec4899'];

export function InventoryCharts({ 
  inventoryData 
}: { 
  inventoryData: { group: string; count: number }[] 
}) {
  const pieData = inventoryData.filter(d => d.count > 0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Bar Chart */}
      <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div className="mb-4">
          <h3 className="font-bold text-gray-900 text-base">Units Available by Blood Group</h3>
          <p className="text-xs text-gray-400">Real-time inventory levels across central storage</p>
        </div>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={inventoryData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="group" tickLine={false} axisLine={false} tick={{ fill: '#6b7280', fontSize: 12, fontWeight: 700 }} />
              <YAxis allowDecimals={false} tickLine={false} axisLine={false} tick={{ fill: '#9ca3af', fontSize: 11 }} />
              <Tooltip 
                cursor={{ fill: '#fef2f2' }}
                contentStyle={{ borderRadius: '12px', border: '1px solid #fee2e2', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                formatter={(value) => [`${value} Units`, 'Inventory']}
              />
              <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                {inventoryData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.count < 2 ? '#f87171' : entry.count < 5 ? '#fbbf24' : '#ef4444'} 
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Pie Chart */}
      <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div className="mb-4">
          <h3 className="font-bold text-gray-900 text-base">Blood Group Distribution</h3>
          <p className="text-xs text-gray-400">Share of available units in network</p>
        </div>
        <div className="h-72 w-full">
          {pieData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-xs text-gray-400">
              No data available to plot
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={4}
                  dataKey="count"
                  nameKey="group"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: '1px solid #e5e7eb' }}
                  formatter={(value, name) => [`${value} Units (${name})`, 'Stock']}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}
