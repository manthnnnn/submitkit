import { prisma } from '@/lib/prisma';
import { 
  Activity, 
  Droplets, 
  Users, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight, 
  PlusCircle, 
  Heart, 
  Phone, 
  MapPin, 
  Building,
  PackageCheck
} from 'lucide-react';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  const [donors, requests, bloodBags] = await Promise.all([
    prisma.donor.findMany({ orderBy: { createdAt: 'desc' } }),
    prisma.bloodRequest.findMany({ orderBy: { createdAt: 'desc' } }),
    prisma.bloodBag.findMany()
  ]);

  const availableBags = bloodBags.filter(b => b.status === 'AVAILABLE');
  const dispensedBags = bloodBags.filter(b => b.status === 'DISPENSED');

  const totalDonors = donors.length;
  const pendingRequests = requests.filter(r => r.status === 'PENDING');

  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const inventory = bloodGroups.map(bg => ({
    group: bg,
    count: availableBags.filter(b => b.bloodGroup === bg).length
  }));

  return (
    <div className="space-y-8">
      {/* Top Hero Banner with Viva Demonstration Roadmap */}
      <div className="bg-gradient-to-r from-red-600 to-rose-700 rounded-3xl p-6 md:p-8 text-white shadow-xl shadow-red-600/10 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold tracking-wide">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              Central Blood Bank Dispatch Console Online
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">LifeDrop: Smart Blood Bank System</h1>
            <p className="text-red-100 text-xs md:text-sm max-w-xl">
              End-to-end blood lifecycle management: from donor registration and cold-vault serialization to ICU emergency dispatch.
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5">
            <Link 
              href="/requests/new"
              className="bg-white text-red-700 hover:bg-red-50 font-bold px-4 py-2.5 rounded-xl text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" /> Hospital Request
            </Link>
            <Link 
              href="/donors/new"
              className="bg-red-800/60 hover:bg-red-800 text-white border border-white/20 font-bold px-4 py-2.5 rounded-xl text-xs transition-all flex items-center gap-1.5"
            >
              <Heart className="w-4 h-4" /> Register Donor
            </Link>
          </div>
        </div>

        {/* 4-Step Guided Presentation Workflow for Evaluators */}
        <div className="pt-4 border-t border-white/20">
          <p className="text-[11px] uppercase tracking-widest font-black text-red-200 mb-2.5">
            Complete 4-Step Clinical Workflow
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
            <Link href="/donors/new" className="bg-white/10 hover:bg-white/20 p-3 rounded-2xl border border-white/15 transition-all">
              <span className="font-mono text-red-200 font-bold">01.</span>
              <p className="font-bold text-white mt-0.5">Register Donor</p>
              <p className="text-[11px] text-red-100/80">Log voluntary donors in directory</p>
            </Link>
            <Link href="/donors" className="bg-white/10 hover:bg-white/20 p-3 rounded-2xl border border-white/15 transition-all">
              <span className="font-mono text-red-200 font-bold">02.</span>
              <p className="font-bold text-white mt-0.5">Collect Blood Bag</p>
              <p className="text-[11px] text-red-100/80">Adds serialized bag to cold vault</p>
            </Link>
            <Link href="/requests/new" className="bg-white/10 hover:bg-white/20 p-3 rounded-2xl border border-white/15 transition-all">
              <span className="font-mono text-red-200 font-bold">03.</span>
              <p className="font-bold text-white mt-0.5">Hospital ICU Order</p>
              <p className="text-[11px] text-red-100/80">Submit emergency requisition</p>
            </Link>
            <Link href="/requests" className="bg-white/10 hover:bg-white/20 p-3 rounded-2xl border border-white/15 transition-all">
              <span className="font-mono text-red-200 font-bold">04.</span>
              <p className="font-bold text-white mt-0.5">Dispense & Print Slip</p>
              <p className="text-[11px] text-red-100/80">Deducts stock & prints handover slip</p>
            </Link>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 flex items-center gap-4">
          <div className="bg-red-50 p-3.5 rounded-2xl text-red-600 shrink-0">
            <Droplets className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Available Bags</p>
            <p className="text-2xl font-black text-gray-900">{availableBags.length} <span className="text-xs font-medium text-gray-400">In Vault</span></p>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 flex items-center gap-4">
          <div className="bg-blue-50 p-3.5 rounded-2xl text-blue-600 shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Registered Donors</p>
            <p className="text-2xl font-black text-gray-900">{totalDonors} <span className="text-xs font-medium text-gray-400">People</span></p>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 flex items-center gap-4">
          <div className="bg-amber-50 p-3.5 rounded-2xl text-amber-600 shrink-0">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Active Emergencies</p>
            <p className="text-2xl font-black text-gray-900">{pendingRequests.length} <span className="text-xs font-medium text-amber-600 font-bold">Pending</span></p>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 flex items-center gap-4">
          <div className="bg-emerald-50 p-3.5 rounded-2xl text-emerald-600 shrink-0">
            <PackageCheck className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">Units Dispensed</p>
            <p className="text-2xl font-black text-gray-900">{dispensedBags.length} <span className="text-xs font-medium text-emerald-600 font-bold">Issued</span></p>
          </div>
        </div>
      </div>

      {/* Real-time Inventory Grid */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <Activity className="w-5 h-5 text-red-600" />
              Live Blood Group Stock in Cold Vault
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">Updated automatically when units are collected or dispensed.</p>
          </div>
          <Link href="/inventory" className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1">
            Detailed Analytics & Bags Table <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {inventory.map(inv => {
            const isDeficit = inv.count < 2;
            return (
              <div 
                key={inv.group} 
                className={`rounded-2xl p-3.5 flex flex-col items-center justify-center text-center border transition-all ${
                  isDeficit 
                    ? 'bg-red-50/50 border-red-200 shadow-sm' 
                    : 'bg-gray-50 border-gray-200 hover:border-gray-300'
                }`}
              >
                <span className="text-2xl font-black text-gray-900">{inv.group}</span>
                <span className={`text-xs font-bold mt-1 ${isDeficit ? 'text-red-600' : 'text-gray-500'}`}>
                  {inv.count} Bags
                </span>
                <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2.5 overflow-hidden">
                  <div 
                    className={`h-full ${inv.count >= 4 ? 'bg-emerald-500' : inv.count > 0 ? 'bg-amber-500' : 'bg-red-400'}`}
                    style={{ width: `${Math.min(inv.count * 25, 100)}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Split Section: Emergency Requisitions & Voluntary Donors */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Urgent Requests */}
        <div className="lg:col-span-6 bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-900 text-base flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-amber-500" />
                Urgent Hospital Orders ({pendingRequests.length})
              </h3>
              <Link href="/requests" className="text-xs font-bold text-red-600 hover:underline">
                View Queue
              </Link>
            </div>

            <div className="space-y-3">
              {pendingRequests.length === 0 ? (
                <div className="py-10 text-center text-gray-400 text-xs">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                  All hospital requisitions fulfilled.
                </div>
              ) : (
                pendingRequests.slice(0, 4).map(req => (
                  <div key={req.id} className="p-3.5 rounded-2xl border border-gray-100 hover:border-gray-200 bg-gray-50/50 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-10 h-10 rounded-xl bg-red-600 text-white font-black text-base flex items-center justify-center shrink-0 shadow-sm">
                        {req.bloodGroup}
                      </span>
                      <div>
                        <p className="text-xs font-bold text-gray-900">{req.patientName}</p>
                        <p className="text-[11px] text-gray-500 flex items-center gap-1 mt-0.5">
                          <Building className="w-3 h-3 text-gray-400" /> {req.hospital}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                        req.urgency === 'Critical' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {req.urgency}
                      </span>
                      <Link 
                        href="/requests"
                        className="text-xs font-bold bg-white text-gray-700 hover:text-red-600 border border-gray-200 px-2.5 py-1 rounded-lg transition-colors"
                      >
                        Allocate
                      </Link>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <Link 
            href="/requests/new" 
            className="block text-center mt-4 text-xs font-bold text-red-600 hover:text-red-700 pt-3 border-t border-gray-50"
          >
            + New Emergency Requisition Form
          </Link>
        </div>

        {/* Recently Registered Donors */}
        <div className="lg:col-span-6 bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-900 text-base flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-500" />
                Active Voluntary Donors ({donors.length})
              </h3>
              <Link href="/donors" className="text-xs font-bold text-red-600 hover:underline">
                View Directory
              </Link>
            </div>

            <div className="space-y-3">
              {donors.length === 0 ? (
                <div className="py-10 text-center text-gray-400 text-xs">
                  No donors registered in database yet.
                </div>
              ) : (
                donors.slice(0, 4).map(donor => (
                  <div key={donor.id} className="p-3.5 rounded-2xl border border-gray-100 hover:border-gray-200 bg-gray-50/50 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-10 h-10 rounded-xl bg-red-50 text-red-600 font-black text-base flex items-center justify-center border border-red-100 shrink-0">
                        {donor.bloodGroup}
                      </span>
                      <div>
                        <p className="text-xs font-bold text-gray-900">{donor.fullName}</p>
                        <p className="text-[11px] text-gray-500 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-gray-400" /> {donor.city} • {donor.totalDonations} Donations
                        </p>
                      </div>
                    </div>

                    <a 
                      href={`tel:${donor.phone}`}
                      className="text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1 rounded-lg transition-colors flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3" /> Call
                    </a>
                  </div>
                ))
              )}
            </div>
          </div>

          <Link 
            href="/donors/new" 
            className="block text-center mt-4 text-xs font-bold text-red-600 hover:text-red-700 pt-3 border-t border-gray-50"
          >
            + Register New Voluntary Donor
          </Link>
        </div>
      </div>
    </div>
  );
}
