'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  CheckCircle2, 
  Building, 
  Phone, 
  PlusCircle, 
  Trash2, 
  Clock, 
  Users, 
  MapPin, 
  ArrowRight,
  ShieldAlert,
  Droplet,
  FileText,
  PackageCheck
} from 'lucide-react';
import { dispenseBlood, deleteRequest } from '@/app/actions';
import { BloodIssueReceiptModal } from '@/components/PrintModals';

interface BloodRequest {
  id: string;
  requestCode: string;
  patientName: string;
  bloodGroup: string;
  unitsRequired: number;
  hospital: string;
  city: string;
  doctorName: string;
  urgency: string;
  status: string;
  dispensedBagCodes?: string | null;
  createdAt: Date;
  dispensedAt?: Date | null;
}

interface BloodBag {
  id: string;
  bagCode: string;
  bloodGroup: string;
  storageRack: string;
  status: string;
  expiresAt: Date;
}

interface Donor {
  id: string;
  fullName: string;
  bloodGroup: string;
  phone: string;
  city: string;
  lastDonated: Date | null;
}

// Biological Compatibility Matrix
const COMPATIBLE_DONORS_MAP: Record<string, string[]> = {
  'O-': ['O-'],
  'O+': ['O+', 'O-'],
  'A-': ['A-', 'O-'],
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'B-': ['B-', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'AB-': ['AB-', 'A-', 'B-', 'O-'],
  'AB+': ['AB+', 'AB-', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-']
};

export function RequestsClient({ 
  initialRequests, 
  availableBags,
  donors 
}: { 
  initialRequests: BloodRequest[]; 
  availableBags: BloodBag[];
  donors: Donor[];
}) {
  const [selectedRequest, setSelectedRequest] = useState<BloodRequest | null>(
    initialRequests.find(r => r.status === 'PENDING') || initialRequests[0] || null
  );
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'PENDING' | 'DISPENSED'>('ALL');
  const [isDispensing, setIsDispensing] = useState(false);
  const [receiptRequest, setReceiptRequest] = useState<BloodRequest | null>(null);

  const filteredRequests = initialRequests.filter(req => {
    if (filterStatus === 'ALL') return true;
    return req.status === filterStatus;
  });

  const getCompatibleBloodGroups = (group: string) => {
    return COMPATIBLE_DONORS_MAP[group] || [group];
  };

  const compatibleGroups = selectedRequest ? getCompatibleBloodGroups(selectedRequest.bloodGroup) : [];

  // Filter blood bags currently in stock that match this patient
  const matchingStockBags = availableBags.filter(
    bag => bag.status === 'AVAILABLE' && compatibleGroups.includes(bag.bloodGroup)
  );

  // Filter voluntary donors matching this patient
  const compatibleDonors = donors.filter(
    d => compatibleGroups.includes(d.bloodGroup)
  );

  const handleDispense = async (bag: BloodBag) => {
    if (!selectedRequest) return;
    setIsDispensing(true);
    await dispenseBlood(selectedRequest.id, bag.id, bag.bagCode);
    setIsDispensing(false);

    const updated = {
      ...selectedRequest,
      status: 'DISPENSED',
      dispensedBagCodes: bag.bagCode,
      dispensedAt: new Date()
    };
    setSelectedRequest(updated);
    setReceiptRequest(updated);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this emergency request record?')) {
      await deleteRequest(id);
      if (selectedRequest?.id === id) {
        setSelectedRequest(null);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight">Hospital Requisition Dispatch</h1>
          <p className="text-gray-500 text-sm mt-1">Live ICU emergency orders with automated blood bag allocation and dispatch slips.</p>
        </div>
        <Link 
          href="/requests/new" 
          className="inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold shadow-sm transition-all"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Hospital Request</span>
        </Link>
      </div>

      {/* Presentation Guidance Tip */}
      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-blue-900">
        <span className="font-bold bg-blue-200 text-blue-900 px-2 py-0.5 rounded text-[10px] uppercase tracking-wider">How to test</span>
        <div>
          Select any pending emergency order on the left. Click <strong>&quot;Dispense Blood Bag&quot;</strong> from the matching cold-storage units. It will automatically deduct the unit from inventory and generate an official <strong>Printable Blood Handover Slip</strong>!
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 border-b border-gray-200 pb-3">
        {(['ALL', 'PENDING', 'DISPENSED'] as const).map(status => (
          <button
            key={status}
            onClick={() => setFilterStatus(status)}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              filterStatus === status
                ? 'bg-red-600 text-white shadow-sm'
                : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            {status === 'ALL' ? 'All Requisitions' : status === 'PENDING' ? 'Pending ICU Orders' : 'Dispensed / Completed'}
          </button>
        ))}
      </div>

      {/* Main Grid: Left = Queue, Right = Dispenser & Matcher */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Requisitions */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="text-xs font-black uppercase text-gray-400 tracking-wider">
            Requisition Queue ({filteredRequests.length})
          </h3>

          {filteredRequests.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-100 p-8 text-center">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-gray-800">No requests in this queue</p>
            </div>
          ) : (
            filteredRequests.map(req => {
              const isSelected = selectedRequest?.id === req.id;
              const isCritical = req.urgency === 'Critical';
              return (
                <div
                  key={req.id}
                  onClick={() => setSelectedRequest(req)}
                  className={`cursor-pointer rounded-2xl p-4 transition-all border ${
                    isSelected 
                      ? 'bg-red-50/70 border-red-500 shadow-sm ring-1 ring-red-500' 
                      : 'bg-white border-gray-200 hover:border-gray-300 shadow-sm'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-red-600 text-white font-black text-xl flex items-center justify-center shadow-md shadow-red-600/20">
                        {req.bloodGroup}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-mono font-bold text-gray-400">{req.requestCode}</span>
                          <span className="text-xs font-bold text-gray-900">• {req.patientName}</span>
                        </div>
                        <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                          <Building className="w-3 h-3 text-gray-400" /> {req.hospital}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1.5">
                      <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        isCritical 
                          ? 'bg-red-100 text-red-700 animate-pulse' 
                          : req.urgency === 'Urgent'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-blue-100 text-blue-700'
                      }`}>
                        {req.urgency}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        req.status === 'PENDING' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-700'
                      }`}>
                        {req.status}
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-gray-100/80 flex items-center justify-between text-[11px] text-gray-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {new Date(req.createdAt).toLocaleDateString('en-GB')}
                    </span>
                    <span className="text-red-600 font-bold flex items-center gap-1">
                      {req.status === 'DISPENSED' ? 'View Handover Slip' : 'Allocate Stock'} <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Interactive Stock Dispatcher & Matcher */}
        <div className="lg:col-span-7">
          {selectedRequest ? (
            <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-6">
              {/* Selected Request Summary */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-black text-red-600">{selectedRequest.bloodGroup}</span>
                    <h2 className="text-xl font-bold text-gray-900">{selectedRequest.patientName}</h2>
                  </div>
                  <p className="text-xs text-gray-500 mt-1 flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5 text-gray-400" /> {selectedRequest.hospital} ({selectedRequest.city})
                  </p>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    Requisition ID: <strong>{selectedRequest.requestCode}</strong> • Physician: {selectedRequest.doctorName}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {selectedRequest.status === 'DISPENSED' && (
                    <button
                      onClick={() => setReceiptRequest(selectedRequest)}
                      className="bg-gray-900 hover:bg-black text-white text-xs font-bold px-3.5 py-2 rounded-xl transition-all shadow-sm flex items-center gap-1.5"
                    >
                      <FileText className="w-3.5 h-3.5" /> Print Issue Slip
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(selectedRequest.id)}
                    className="p-2 text-gray-400 hover:text-red-600 rounded-xl hover:bg-red-50 transition-colors"
                    title="Delete Request"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Compatibility Algorithm Badge */}
              <div className="bg-blue-50/70 border border-blue-100 rounded-2xl p-3.5 text-xs text-blue-900">
                <span className="font-bold">Clinical Matching Rule:</span> A patient with <strong>{selectedRequest.bloodGroup}</strong> can safely receive blood from compatible groups: <strong>{compatibleGroups.join(', ')}</strong>.
              </div>

              {/* Status Banner */}
              {selectedRequest.status === 'DISPENSED' && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
                  <div className="flex items-center gap-2.5 text-emerald-800 text-xs font-bold">
                    <PackageCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span>Transfusion Unit Issued: {selectedRequest.dispensedBagCodes}</span>
                  </div>
                  <button
                    onClick={() => setReceiptRequest(selectedRequest)}
                    className="text-xs font-bold underline text-emerald-800 hover:text-emerald-900"
                  >
                    View Official Receipt
                  </button>
                </div>
              )}

              {/* SECTION A: Ready-to-Dispense Blood Bags in Vault */}
              {selectedRequest.status === 'PENDING' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black uppercase text-gray-500 tracking-wider flex items-center gap-1.5">
                      <Droplet className="w-4 h-4 text-red-600" /> Compatible Blood Bags in Cold Storage ({matchingStockBags.length})
                    </h4>
                  </div>

                  {matchingStockBags.length === 0 ? (
                    <div className="p-5 text-center bg-red-50 rounded-2xl border border-red-100">
                      <ShieldAlert className="w-7 h-7 text-red-500 mx-auto mb-1.5" />
                      <h5 className="font-bold text-red-900 text-xs">No Compatible Bags Currently in Cold Storage</h5>
                      <p className="text-[11px] text-red-700 mt-0.5">
                        Please appeal to the matching voluntary donors listed below to donate immediately.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                      {matchingStockBags.map(bag => (
                        <div key={bag.id} className="p-3 bg-gray-50 hover:bg-gray-100 rounded-xl border border-gray-200 flex items-center justify-between gap-3 transition-colors">
                          <div className="flex items-center gap-3">
                            <span className="w-9 h-9 rounded-lg bg-red-600 text-white font-black text-xs flex items-center justify-center">
                              {bag.bloodGroup}
                            </span>
                            <div>
                              <p className="font-mono text-xs font-bold text-gray-900">{bag.bagCode}</p>
                              <p className="text-[11px] text-gray-500">{bag.storageRack} • Expires: {new Date(bag.expiresAt).toLocaleDateString('en-GB')}</p>
                            </div>
                          </div>

                          <button
                            onClick={() => handleDispense(bag)}
                            disabled={isDispensing}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3.5 py-1.5 rounded-lg shadow-sm transition-all flex items-center gap-1.5"
                          >
                            <PackageCheck className="w-3.5 h-3.5" /> Dispense Bag
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* SECTION B: On-Call Voluntary Donors */}
              <div className="space-y-3 pt-2 border-t border-gray-100">
                <h4 className="text-xs font-black uppercase text-gray-500 tracking-wider flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-blue-500" /> Compatible Donors for Emergency Backup ({compatibleDonors.length})
                </h4>

                <div className="divide-y divide-gray-100 max-h-48 overflow-y-auto pr-1">
                  {compatibleDonors.map(donor => (
                    <div key={donor.id} className="py-2.5 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <span className="w-7 h-7 rounded-md bg-red-50 text-red-700 font-bold text-xs flex items-center justify-center">
                          {donor.bloodGroup}
                        </span>
                        <div>
                          <p className="text-xs font-bold text-gray-900">{donor.fullName}</p>
                          <p className="text-[10px] text-gray-400 flex items-center gap-1">
                            <MapPin className="w-2.5 h-2.5" /> {donor.city}
                          </p>
                        </div>
                      </div>

                      <a 
                        href={`tel:${donor.phone}`}
                        className="text-[11px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1"
                      >
                        <Phone className="w-3 h-3" /> Call ({donor.phone})
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-gray-200 p-12 text-center text-gray-400">
              Select an emergency requisition from the queue to view inventory allocation options.
            </div>
          )}
        </div>
      </div>

      {/* Printable Receipt Modal */}
      {receiptRequest && (
        <BloodIssueReceiptModal
          request={receiptRequest}
          onClose={() => setReceiptRequest(null)}
        />
      )}
    </div>
  );
}
