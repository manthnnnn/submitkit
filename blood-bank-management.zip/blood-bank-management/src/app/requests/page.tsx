import { prisma } from '@/lib/prisma';
import { RequestsClient } from './RequestsClient';

export const dynamic = 'force-dynamic';

export default async function RequestsPage() {
  const [requests, availableBags, donors] = await Promise.all([
    prisma.bloodRequest.findMany({ orderBy: { createdAt: 'desc' } }),
    prisma.bloodBag.findMany({ orderBy: { collectedAt: 'desc' } }),
    prisma.donor.findMany({ orderBy: { createdAt: 'desc' } })
  ]);

  return (
    <RequestsClient 
      initialRequests={requests} 
      availableBags={availableBags} 
      donors={donors} 
    />
  );
}
