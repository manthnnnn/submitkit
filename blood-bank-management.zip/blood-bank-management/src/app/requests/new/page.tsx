'use client';

import { createRequest } from '@/app/actions';
import { User, Building, AlertCircle } from 'lucide-react';
import { useFormStatus } from 'react-dom';

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button 
      type="submit" 
      disabled={pending}
      className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-xl transition-all shadow-sm disabled:opacity-50"
    >
      {pending ? 'Broadcasting Alert...' : 'Submit Emergency Request'}
    </button>
  );
}

export default function RequestBloodPage() {
  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  return (
    <div className="max-w-xl mx-auto">
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
        <div className="text-center mb-8">
          <div className="bg-amber-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-amber-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Request Blood</h1>
          <p className="text-gray-500 mt-2">Find matching donors in your area instantly.</p>
        </div>

        <form action={createRequest} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Patient Name</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User className="h-5 w-5 text-gray-400" />
              </div>
              <input type="text" name="patientName" required className="pl-10 block w-full rounded-xl border-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 bg-gray-50 border p-3 outline-none" placeholder="Jane Doe" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Required Blood Group</label>
            <select name="bloodGroup" required className="block w-full rounded-xl border-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 bg-gray-50 border p-3 outline-none">
              <option value="">Select blood group</option>
              {bloodGroups.map(bg => (
                <option key={bg} value={bg}>{bg}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Hospital Name & City</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Building className="h-5 w-5 text-gray-400" />
              </div>
              <input type="text" name="hospital" required className="pl-10 block w-full rounded-xl border-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 bg-gray-50 border p-3 outline-none" placeholder="City General Hospital, NY" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Urgency Level</label>
            <select name="urgency" required className="block w-full rounded-xl border-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 bg-gray-50 border p-3 outline-none">
              <option value="Standard">Standard (Within 24 Hours)</option>
              <option value="Urgent">Urgent (Within 6 Hours)</option>
              <option value="Critical">Critical (Immediate)</option>
            </select>
          </div>

          <div className="pt-4">
            <SubmitButton />
          </div>
        </form>
      </div>
    </div>
  );
}
