'use server'

import { prisma } from '@/lib/prisma'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

export async function registerDonor(formData: FormData) {
  const fullName = formData.get('fullName') as string
  const bloodGroup = formData.get('bloodGroup') as string
  const phone = formData.get('phone') as string
  const email = formData.get('email') as string || null
  const city = formData.get('city') as string
  const age = parseInt(formData.get('age') as string || '25', 10)
  const gender = formData.get('gender') as string || 'Not Specified'

  if (!fullName || !bloodGroup || !phone || !city) {
    throw new Error('All mandatory fields are required')
  }

  await prisma.donor.create({
    data: {
      fullName,
      bloodGroup,
      phone,
      email,
      city,
      age,
      gender,
      totalDonations: 0,
      lastDonated: null
    }
  })

  revalidatePath('/')
  revalidatePath('/donors')
  revalidatePath('/inventory')
  redirect('/donors')
}

export async function collectBloodBag(formData: FormData) {
  const donorId = formData.get('donorId') as string
  const bloodGroup = formData.get('bloodGroup') as string
  const storageRack = formData.get('storageRack') as string || 'Cold Rack A-1'
  const donorName = formData.get('donorName') as string || 'Voluntary Donor'

  const randomDigits = Math.floor(1000 + Math.random() * 9000)
  const cleanGroup = bloodGroup.replace('+', 'P').replace('-', 'N')
  const bagCode = `BAG-${cleanGroup}-${randomDigits}`

  const now = new Date()
  const expiresAt = new Date(now.getTime() + 42 * 24 * 60 * 60 * 1000) // Whole blood shelf life: 42 days

  await prisma.bloodBag.create({
    data: {
      bagCode,
      bloodGroup,
      storageRack,
      donorId: donorId || null,
      donorName,
      collectedAt: now,
      expiresAt,
      status: 'AVAILABLE'
    }
  })

  if (donorId) {
    await prisma.donor.update({
      where: { id: donorId },
      data: {
        lastDonated: now,
        totalDonations: { increment: 1 }
      }
    })
  }

  revalidatePath('/')
  revalidatePath('/donors')
  revalidatePath('/inventory')
}

export async function deleteDonor(id: string) {
  await prisma.donor.delete({
    where: { id }
  })
  revalidatePath('/')
  revalidatePath('/donors')
  revalidatePath('/inventory')
}

export async function createRequest(formData: FormData) {
  const patientName = formData.get('patientName') as string
  const bloodGroup = formData.get('bloodGroup') as string
  const unitsRequired = parseInt(formData.get('unitsRequired') as string || '1', 10)
  const hospital = formData.get('hospital') as string
  const city = formData.get('city') as string || 'Mumbai'
  const doctorName = formData.get('doctorName') as string || 'Dr. On-Duty Specialist'
  const urgency = formData.get('urgency') as string || 'Standard'

  if (!patientName || !bloodGroup || !hospital) {
    throw new Error('Mandatory fields missing')
  }

  const randomNum = Math.floor(100 + Math.random() * 900)
  const requestCode = `REQ-2026-${randomNum}`

  await prisma.bloodRequest.create({
    data: {
      requestCode,
      patientName,
      bloodGroup,
      unitsRequired,
      hospital,
      city,
      doctorName,
      urgency,
      status: 'PENDING'
    }
  })

  revalidatePath('/')
  revalidatePath('/requests')
  revalidatePath('/inventory')
  redirect('/requests')
}

export async function dispenseBlood(requestId: string, bagId: string, bagCode: string) {
  await prisma.$transaction([
    prisma.bloodBag.update({
      where: { id: bagId },
      data: { status: 'DISPENSED' }
    }),
    prisma.bloodRequest.update({
      where: { id: requestId },
      data: {
        status: 'DISPENSED',
        dispensedBagCodes: bagCode,
        dispensedAt: new Date()
      }
    })
  ])

  revalidatePath('/')
  revalidatePath('/requests')
  revalidatePath('/inventory')
}

export async function deleteRequest(id: string) {
  await prisma.bloodRequest.delete({
    where: { id }
  })
  revalidatePath('/')
  revalidatePath('/requests')
  revalidatePath('/inventory')
}
