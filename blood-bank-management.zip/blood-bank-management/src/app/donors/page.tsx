import { prisma } from '@/lib/prisma';
import { DonorsClient } from './DonorsClient';

export const dynamic = 'force-dynamic';

export default async function DonorsPage() {
  const donors = await prisma.donor.findMany({
    orderBy: { createdAt: 'desc' }
  });

  return <DonorsClient initialDonors={donors} />;
}
