'use client';

import { registerDonor } from '@/app/actions';
import { Heart, User, MapPin, Phone } from 'lucide-react';
import { useFormStatus } from 'react-dom';

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button 
      type="submit" 
      disabled={pending}
      className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-xl transition-all shadow-sm disabled:opacity-50"
    >
      {pending ? 'Registering...' : 'Register as Donor'}
    </button>
  );
}

export default function RegisterDonorPage() {
  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  return (
    <div className="max-w-xl mx-auto">
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
        <div className="text-center mb-8">
          <div className="bg-red-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="w-8 h-8 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Become a Donor</h1>
          <p className="text-gray-500 mt-2">Your single donation can save up to three lives.</p>
        </div>

        <form action={registerDonor} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User className="h-5 w-5 text-gray-400" />
              </div>
              <input type="text" name="fullName" required className="pl-10 block w-full rounded-xl border-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 bg-gray-50 border p-3 outline-none" placeholder="John Doe" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Blood Group</label>
            <select name="bloodGroup" required className="block w-full rounded-xl border-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 bg-gray-50 border p-3 outline-none">
              <option value="">Select blood group</option>
              {bloodGroups.map(bg => (
                <option key={bg} value={bg}>{bg}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Phone className="h-5 w-5 text-gray-400" />
              </div>
              <input type="tel" name="phone" required className="pl-10 block w-full rounded-xl border-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 bg-gray-50 border p-3 outline-none" placeholder="+1 (555) 000-0000" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MapPin className="h-5 w-5 text-gray-400" />
              </div>
              <input type="text" name="city" required className="pl-10 block w-full rounded-xl border-gray-200 shadow-sm focus:border-red-500 focus:ring-red-500 bg-gray-50 border p-3 outline-none" placeholder="New York" />
            </div>
          </div>

          <div className="pt-4">
            <SubmitButton />
          </div>
        </form>
      </div>
    </div>
  );
}
