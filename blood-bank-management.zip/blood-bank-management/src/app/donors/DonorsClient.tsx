'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  Phone, 
  MapPin, 
  Calendar, 
  Search, 
  Filter, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  PlusCircle, 
  Droplet, 
  Award,
  X
} from 'lucide-react';
import { deleteDonor, collectBloodBag } from '@/app/actions';
import { DonorCertificateModal } from '@/components/PrintModals';

interface Donor {
  id: string;
  fullName: string;
  bloodGroup: string;
  phone: string;
  email: string | null;
  city: string;
  age: number | null;
  gender: string | null;
  totalDonations: number;
  lastDonated: Date | null;
  createdAt: Date;
}

export function DonorsClient({ initialDonors }: { initialDonors: Donor[] }) {
  const [search, setSearch] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('ALL');
  const [isDeleting, setIsDeleting] = useState<string | null>(null);

  // Modals state
  const [certDonor, setCertDonor] = useState<Donor | null>(null);
  const [collectingDonor, setCollectingDonor] = useState<Donor | null>(null);
  const [selectedRack, setSelectedRack] = useState('Cold Rack A-1');
  const [isCollecting, setIsCollecting] = useState(false);

  const bloodGroups = ['ALL', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  const filteredDonors = initialDonors.filter(donor => {
    const matchesSearch = 
      donor.fullName.toLowerCase().includes(search.toLowerCase()) ||
      donor.city.toLowerCase().includes(search.toLowerCase()) ||
      donor.phone.includes(search);
    const matchesGroup = selectedGroup === 'ALL' || donor.bloodGroup === selectedGroup;
    return matchesSearch && matchesGroup;
  });

  const checkEligibility = (lastDonated: Date | null) => {
    if (!lastDonated) return { eligible: true, daysLeft: 0 };
    const diffTime = Math.abs(new Date().getTime() - new Date(lastDonated).getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    if (diffDays >= 90) {
      return { eligible: true, daysLeft: 0 };
    }
    return { eligible: false, daysLeft: 90 - diffDays };
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to remove this donor from the directory?')) {
      setIsDeleting(id);
      await deleteDonor(id);
      setIsDeleting(null);
    }
  };

  const handleCollectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!collectingDonor) return;
    setIsCollecting(true);

    const formData = new FormData();
    formData.append('donorId', collectingDonor.id);
    formData.append('donorName', collectingDonor.fullName);
    formData.append('bloodGroup', collectingDonor.bloodGroup);
    formData.append('storageRack', selectedRack);

    await collectBloodBag(formData);
    setIsCollecting(false);
    const donorForCert = collectingDonor;
    setCollectingDonor(null);
    setCertDonor(donorForCert);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight">Voluntary Donor Network</h1>
          <p className="text-gray-500 text-sm mt-1">Manage verified donors, track 90-day cooldowns, and collect blood units into inventory.</p>
        </div>
        <Link 
          href="/donors/new" 
          className="inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold shadow-sm transition-all"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Register New Donor</span>
        </Link>
      </div>

      {/* Presentation Guidance Tip */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-amber-900">
        <span className="font-bold bg-amber-200 text-amber-900 px-2 py-0.5 rounded text-[10px] uppercase tracking-wider">How to test</span>
        <div>
          Click <strong>&quot;Collect Blood Unit&quot;</strong> on any eligible donor below. It will automatically assign a serialized blood bag into the central cold-chain storage and pop up an official <strong>Printable Appreciation Certificate</strong>!
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input 
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by donor name, city, or phone..."
              className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filter:
            </span>
            {bloodGroups.map(group => (
              <button
                key={group}
                onClick={() => setSelectedGroup(group)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  selectedGroup === group
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {group}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Donor Cards Grid */}
      {filteredDonors.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center">
          <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-gray-900">No Donors Found</h3>
          <p className="text-gray-500 text-sm mt-1 max-w-sm mx-auto">
            No donor matched your search criteria. Try adjusting the search query or blood group filter.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredDonors.map(donor => {
            const eligibility = checkEligibility(donor.lastDonated);
            return (
              <div 
                key={donor.id}
                className="bg-white rounded-3xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-red-600 text-white font-black text-xl flex items-center justify-center shadow-md shadow-red-600/20">
                        {donor.bloodGroup}
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 text-base flex items-center gap-1.5">
                          {donor.fullName}
                        </h3>
                        <span className="inline-flex items-center gap-1 text-xs text-gray-500">
                          <MapPin className="w-3 h-3 text-gray-400" /> {donor.city} {donor.age ? `• ${donor.age} yrs` : ''}
                        </span>
                      </div>
                    </div>
                    <button 
                      onClick={() => handleDelete(donor.id)}
                      disabled={isDeleting === donor.id}
                      className="text-gray-300 hover:text-red-500 p-1 rounded-lg transition-colors"
                      title="Delete Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-2 py-3 border-y border-gray-50 text-xs text-gray-600">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-gray-400">
                        <Phone className="w-3.5 h-3.5" /> Mobile
                      </span>
                      <a href={`tel:${donor.phone}`} className="font-semibold text-gray-900 hover:text-red-600">
                        {donor.phone}
                      </a>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-gray-400">
                        <Calendar className="w-3.5 h-3.5" /> Last Donation
                      </span>
                      <span className="font-medium text-gray-700">
                        {donor.lastDonated ? new Date(donor.lastDonated).toLocaleDateString('en-GB') : 'First-time Donor'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-gray-400">
                        <Award className="w-3.5 h-3.5 text-amber-500" /> Total Donated
                      </span>
                      <span className="font-bold text-gray-900">
                        {donor.totalDonations} Units
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-2 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    {eligibility.eligible ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                        <CheckCircle2 className="w-3 h-3" /> Eligible to Donate
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full">
                        <AlertCircle className="w-3 h-3" /> Cooldown ({eligibility.daysLeft}d left)
                      </span>
                    )}

                    <button
                      onClick={() => setCertDonor(donor)}
                      className="text-[11px] font-bold text-amber-700 hover:text-amber-800 bg-amber-50 hover:bg-amber-100 px-2.5 py-1 rounded-lg border border-amber-200 transition-colors flex items-center gap-1"
                    >
                      <Award className="w-3 h-3" /> Certificate
                    </button>
                  </div>

                  <button
                    onClick={() => setCollectingDonor(donor)}
                    className="w-full bg-red-50 hover:bg-red-600 text-red-700 hover:text-white font-bold text-xs py-2 rounded-xl border border-red-200 transition-all flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <Droplet className="w-3.5 h-3.5" /> Collect 450ml Blood Unit
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Collect Blood Unit Modal */}
      {collectingDonor && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative border border-gray-100">
            <button 
              onClick={() => setCollectingDonor(null)}
              className="absolute right-4 top-4 p-1.5 text-gray-400 hover:text-gray-700 rounded-full hover:bg-gray-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center mx-auto mb-3 shadow-md shadow-red-600/30">
                <Droplet className="w-6 h-6 fill-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Collect Blood Bag</h3>
              <p className="text-xs text-gray-500 mt-1">
                Logging 450ml of <strong>{collectingDonor.bloodGroup}</strong> from <strong>{collectingDonor.fullName}</strong>
              </p>
            </div>

            <form onSubmit={handleCollectSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Assign Refrigerator / Cold Storage Rack</label>
                <select 
                  value={selectedRack}
                  onChange={(e) => setSelectedRack(e.target.value)}
                  className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-red-500 outline-none"
                >
                  <option value="Cold Rack A-1 (Main Blood Vault)">Cold Rack A-1 (Main Blood Vault)</option>
                  <option value="Cold Rack A-2 (O- Emergency Vault)">Cold Rack A-2 (O- Emergency Vault)</option>
                  <option value="Cold Rack B-1 (A Group Storage)">Cold Rack B-1 (A Group Storage)</option>
                  <option value="Cold Rack C-1 (B Group Storage)">Cold Rack C-1 (B Group Storage)</option>
                  <option value="Cold Rack D-1 (AB Group Storage)">Cold Rack D-1 (AB Group Storage)</option>
                </select>
              </div>

              <div className="bg-gray-50 p-3 rounded-xl border border-gray-200 text-[11px] text-gray-600 space-y-1">
                <p><strong>Volume:</strong> 450 mL (Standard Whole Blood Unit)</p>
                <p><strong>Calculated Expiration:</strong> 42 Days from today (Stored at 2°C to 6°C)</p>
              </div>

              <button
                type="submit"
                disabled={isCollecting}
                className="w-full bg-red-600 hover:bg-red-700 text-white font-bold text-xs py-3 rounded-xl shadow-md transition-all disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                {isCollecting ? 'Saving to Vault...' : 'Confirm Collection & Generate Serial Bag'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Printable Certificate Modal */}
      {certDonor && (
        <DonorCertificateModal 
          donor={certDonor} 
          onClose={() => setCertDonor(null)} 
        />
      )}
    </div>
  );
}
