# VIVA PRESENTATION SCRIPT & EXAMINER Q&A CHEATSHEET
## Project: LifeDrop - Smart Blood Bank Management System

---

## PART 1: 15-SLIDE DEFENSE PRESENTATION SCRIPT

### Slide 1: Title Slide
- **Slide Content:** LifeDrop: A Centralized Smart Blood Bank & Emergency Dispatch Platform.
- **Presenter Name & University Roll Number:** [Your Name / Roll No]
- **Department:** Department of Computer Science & Engineering
- **Speaker Script:**
  > *"Good morning respected external examiner and faculty members. Today, I am presenting 'LifeDrop' — a centralized, real-time blood bank inventory and emergency requisition platform engineered using Next.js 14, TypeScript, and SQLite with Prisma ORM."*

### Slide 2: Problem Statement & Motivation
- **Slide Content:**
  - Severe communication bottlenecks during trauma cases.
  - Independent hospitals maintaining isolated, manual spreadsheets.
  - Lack of biological compatibility checking during triage.
  - Failure to monitor the clinical 90-day donor cooldown period.
- **Speaker Script:**
  > *"During acute medical emergencies like vehicular trauma or cardiovascular operations, finding a compatible blood unit within the golden hour is often the difference between life and death. Traditional blood banks operate in silos with manual record-keeping, forcing family members to physically run from hospital to hospital. Our project eliminates this friction by digitizing and unifying the inventory."*

### Slide 3: Proposed Solution
- **Slide Content:**
  - Real-time stock telemetry across all 8 standard blood groups.
  - Biological Compatibility Engine computed via clinical ABO/Rh algorithms.
  - Emergency triage requisition queue (Critical, Urgent, Standard).
  - Centralized donor directory with automatic cooldown tracking.
- **Speaker Script:**
  > *"To solve these issues, LifeDrop acts as a unified digital dispatch console. Hospitals can broadcast emergency requisitions, and our algorithm instantly filters through hundreds of registered voluntary donors to show who can safely donate."*

### Slide 4: System Architecture
- **Slide Content:** Diagram showing Client (React 18 + Tailwind) -> Server (Next.js 14 Server Actions) -> Prisma ORM -> Embedded SQLite Database.
- **Speaker Script:**
  > *"Our architecture adheres to the modern App Router paradigm. We chose an embedded SQLite database managed via Prisma ORM. This eliminates complex external server configurations while providing robust ACID compliance for critical medical data."*

### Slide 5: Biological Compatibility Engine
- **Slide Content:** Transfusion Matrix Table (O- Universal Donor, AB+ Universal Recipient).
- **Speaker Script:**
  > *"A key innovation of our software is the biological matching algorithm. It does not just look for an exact blood group match; it computes all medically viable donors based on Landsteiner's rules. For example, if an AB- patient needs blood, the system automatically surfaces AB-, A-, B-, and O- donors."*

### Slide 6: Live Demonstration Walkthrough
- **Slide Content:** Live Software Demo on `http://localhost:3000`.
- **Speaker Script:**
  > *"Allow me to demonstrate the live application. Here on the Dashboard, you see real-time inventory counts and deficit warnings. Let us now navigate to Emergency Requests, select a critical requisition, and watch the system instantly isolate verified compatible donors."*

### Slide 7: Technical Stack Justification
- **Slide Content:** Next.js 14, TypeScript, Tailwind CSS, Prisma ORM, Recharts.
- **Speaker Script:**
  > *"We used TypeScript for end-to-end type safety, preventing null reference errors in patient forms. Tailwind CSS provides a high-performance responsive UI, and Recharts renders graphical distribution data for hospital administrators."*

### Slide 8: Future Enhancements & Conclusion
- **Slide Content:** Twilio SMS automated alerts, GPS geofencing, RFID cold-chain monitoring.
- **Speaker Script:**
  > *"In future iterations, we plan to integrate automated SMS gateways to immediately alert donors within a 5-kilometer radius of the hospital. In conclusion, LifeDrop drastically reduces requisition response latency from hours to seconds. Thank you, and I welcome your questions."*

---

## PART 2: TOP 20 VIVA QUESTIONS ASKED BY EXAMINERS (WITH MODEL ANSWERS)

#### Q1: Why did you choose SQLite over MySQL or MongoDB?
**Model Answer:**  
*"SQLite is a serverless, zero-configuration embedded relational database engine. Because it operates as an integrated file (`dev.db`), it eliminates external server dependencies and daemon connection pooling failures, making it exceptionally reliable and lightweight for localized hospital deployments while preserving full ACID transaction guarantees through Prisma ORM."*

#### Q2: What is the significance of the 90-day cooldown period in your donor logic?
**Model Answer:**  
*"Clinically, after donating a unit of whole blood (approx. 350-450 mL), the human body requires 8 to 12 weeks to completely replenish red blood cell hemoglobin levels. Our application enforces a 90-day cooldown algorithm from the `lastDonated` timestamp to ensure donors are medically eligible and not subjected to anemia."*

#### Q3: Who is a universal donor and who is a universal recipient?
**Model Answer:**  
*"O negative (O-) is the universal red cell donor because its erythrocytes lack A, B, and Rh antigens, meaning recipient antibodies will not attack them. Conversely, AB positive (AB+) is the universal red cell recipient because the individual has A, B, and Rh antigens and produces no antibodies against any ABO/Rh blood type."*

#### Q4: How does Next.js 14 App Router improve this application over traditional React?
**Model Answer:**  
*"Next.js 14 uses React Server Components and Server Actions. Instead of requiring a separate Express API layer with client-side `useEffect` data fetching that creates network waterfalls, database operations execute securely on the server with zero client bundle overhead, resulting in instantaneous page loads."*

#### Q5: What is Prisma ORM and how does it prevent SQL injection?
**Model Answer:**  
*"Prisma is a type-safe Object-Relational Mapper. It translates TypeScript schema definitions into validated database operations. Prisma completely eliminates SQL injection vulnerabilities because all database queries use parameterized prepared statements under the hood rather than raw string concatenation."*

#### Q6: How does the system handle concurrent donor registrations or request fulfillments?
**Model Answer:**  
*"SQLite with Prisma handles concurrency through database-level write locks and WAL (Write-Ahead Logging) mode, ensuring that transaction updates (such as fulfilling an emergency requisition) are serialized and executed atomically without race conditions."*

#### Q7: How does your biological compatibility matrix work in code?
**Model Answer:**  
*"In `RequestsClient.tsx`, we defined a constant lookup hashmap `COMPATIBLE_DONORS_MAP` where each recipient blood group key maps to an array of allowable donor blood groups. When an emergency requisition is selected, the algorithm executes a constant time $O(1)$ key lookup and filters the active donor array in $O(N)$ time."*

#### Q8: Can a B- positive patient receive blood from an A- positive donor?
**Model Answer:**  
*"No, because a B+ recipient possesses anti-A antibodies in their plasma. Transfusing A+ blood would cause severe acute hemolytic transfusion reactions (agglutination and red blood cell lysis), which is fatal. Our system strictly prevents this."*

#### Q9: What happens if there are zero compatible donors in the system?
**Model Answer:**  
*"The system displays a prominent 'Critical Shortage / No Compatible Donors' triage warning with advice to immediately initiate inter-hospital emergency transfers and broadcast public donor appeals."*

#### Q10: How can this system scale to handle thousands of hospitals nationwide?
**Model Answer:**  
*"Because the code uses Prisma ORM, migrating from SQLite to a distributed PostgreSQL cluster (such as AWS RDS or Supabase) requires changing just one line in `schema.prisma` (`provider = 'postgresql'`). The business logic and Server Actions remain 100% identical."*
