@echo off
cd /d "%~dp0"
title SubmitKit 1-Click Launcher - LifeDrop Blood Bank
color 0C

echo =====================================================================
echo       LIFEDROP: SMART BLOOD BANK MANAGEMENT SYSTEM
echo       Academic Software Project Bundle ^| SubmitKit Guaranteed
echo =====================================================================
echo.
echo [INFO] Preparing project runtime environment...
echo.

where node >nul 2>nul
if errorlevel 1 goto missing_node

if exist "node_modules\" goto skip_install
echo [STEP 1/3] Installing dependencies silently (this only happens on first run, ~30-60s)...
call npm install --no-audit --no-fund --loglevel=error
if errorlevel 1 goto install_failed

:skip_install
echo [STEP 1/3] Dependencies verified.
echo.
echo [STEP 2/3] Initializing local zero-config SQLite database...
call npx prisma generate
call npx prisma db push --skip-generate
if not exist "prisma\dev.db" (
    echo [INFO] Populating database with sample records...
    call node prisma/seed.js
)

echo.
echo [STEP 3/3] Launching web server...
echo.
echo =====================================================================
echo  SUCCESS: System operational at http://localhost:3000
echo  Keep this terminal window open during your project presentation!
echo =====================================================================
echo.

start http://localhost:3000
call npm run dev

echo.
echo Server stopped.
pause
goto :eof

:missing_node
echo [ERROR] Node.js was not detected on your system.
echo Please install Node.js (LTS version) from: https://nodejs.org
echo Then double-click this run.bat file again.
pause
goto :eof

:install_failed
echo [ERROR] Failed to install NPM packages. Please check your internet connection.
pause
goto :eof
