const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('Seeding LifeDrop with full production-grade healthcare data...');

  await prisma.bloodBag.deleteMany();
  await prisma.bloodRequest.deleteMany();
  await prisma.donor.deleteMany();

  const donors = [
    { fullName: 'Rahul Sharma', bloodGroup: 'O+', phone: '+91 98201 44521', email: 'rahul.s@example.com', city: 'Mumbai', age: 28, gender: 'Male', totalDonations: 4, lastDonated: new Date(Date.now() - 110 * 86400000) },
    { fullName: 'Priya Nair', bloodGroup: 'A+', phone: '+91 98450 12389', email: 'priya.nair@example.com', city: 'Bengaluru', age: 24, gender: 'Female', totalDonations: 2, lastDonated: new Date(Date.now() - 45 * 86400000) },
    { fullName: 'Amit Patel', bloodGroup: 'B+', phone: '+91 98980 55674', email: 'amit.patel@example.com', city: 'Ahmedabad', age: 34, gender: 'Male', totalDonations: 6, lastDonated: new Date(Date.now() - 120 * 86400000) },
    { fullName: 'Ananya Roy', bloodGroup: 'AB+', phone: '+91 98310 99812', email: 'ananya.roy@example.com', city: 'Kolkata', age: 22, gender: 'Female', totalDonations: 1, lastDonated: new Date(Date.now() - 200 * 86400000) },
    { fullName: 'Vikram Malhotra', bloodGroup: 'O-', phone: '+91 98111 67234', email: 'vikram.m@example.com', city: 'New Delhi', age: 31, gender: 'Male', totalDonations: 5, lastDonated: new Date(Date.now() - 95 * 86400000) },
    { fullName: 'Sneha Deshmukh', bloodGroup: 'A-', phone: '+91 97654 33210', email: 'sneha.d@example.com', city: 'Pune', age: 26, gender: 'Female', totalDonations: 3, lastDonated: new Date(Date.now() - 150 * 86400000) },
    { fullName: 'Karthik Raja', bloodGroup: 'B-', phone: '+91 94440 88712', email: 'karthik.r@example.com', city: 'Chennai', age: 29, gender: 'Male', totalDonations: 2, lastDonated: new Date(Date.now() - 30 * 86400000) },
    { fullName: 'Meera Kulkarni', bloodGroup: 'AB-', phone: '+91 98220 77154', email: 'meera.k@example.com', city: 'Pune', age: 27, gender: 'Female', totalDonations: 2, lastDonated: new Date(Date.now() - 180 * 86400000) },
    { fullName: 'Rohan Gupta', bloodGroup: 'O+', phone: '+91 99100 45678', email: 'rohan.g@example.com', city: 'Gurugram', age: 35, gender: 'Male', totalDonations: 8, lastDonated: new Date(Date.now() - 100 * 86400000) },
    { fullName: 'Divya Iyer', bloodGroup: 'A+', phone: '+91 98840 91234', email: 'divya.i@example.com', city: 'Chennai', age: 23, gender: 'Female', totalDonations: 1, lastDonated: new Date(Date.now() - 140 * 86400000) }
  ];

  const createdDonors = [];
  for (const d of donors) {
    const donor = await prisma.donor.create({ data: d });
    createdDonors.push(donor);
  }

  // Pre-seed blood bags in cold storage racks
  const bloodBagsData = [
    { bagCode: 'BAG-OP-1001', bloodGroup: 'O+', storageRack: 'Cold Rack A-1', collectedAt: new Date(Date.now() - 5 * 86400000), expiresAt: new Date(Date.now() + 37 * 86400000), donorName: 'Rahul Sharma' },
    { bagCode: 'BAG-OP-1002', bloodGroup: 'O+', storageRack: 'Cold Rack A-1', collectedAt: new Date(Date.now() - 8 * 86400000), expiresAt: new Date(Date.now() + 34 * 86400000), donorName: 'Rohan Gupta' },
    { bagCode: 'BAG-ON-1003', bloodGroup: 'O-', storageRack: 'Cold Rack A-2', collectedAt: new Date(Date.now() - 3 * 86400000), expiresAt: new Date(Date.now() + 39 * 86400000), donorName: 'Vikram Malhotra' },
    { bagCode: 'BAG-AP-1004', bloodGroup: 'A+', storageRack: 'Cold Rack B-1', collectedAt: new Date(Date.now() - 12 * 86400000), expiresAt: new Date(Date.now() + 30 * 86400000), donorName: 'Priya Nair' },
    { bagCode: 'BAG-AP-1005', bloodGroup: 'A+', storageRack: 'Cold Rack B-1', collectedAt: new Date(Date.now() - 2 * 86400000), expiresAt: new Date(Date.now() + 40 * 86400000), donorName: 'Divya Iyer' },
    { bagCode: 'BAG-AN-1006', bloodGroup: 'A-', storageRack: 'Cold Rack B-2', collectedAt: new Date(Date.now() - 15 * 86400000), expiresAt: new Date(Date.now() + 27 * 86400000), donorName: 'Sneha Deshmukh' },
    { bagCode: 'BAG-BP-1007', bloodGroup: 'B+', storageRack: 'Cold Rack C-1', collectedAt: new Date(Date.now() - 4 * 86400000), expiresAt: new Date(Date.now() + 38 * 86400000), donorName: 'Amit Patel' },
    { bagCode: 'BAG-BP-1008', bloodGroup: 'B+', storageRack: 'Cold Rack C-1', collectedAt: new Date(Date.now() - 1 * 86400000), expiresAt: new Date(Date.now() + 41 * 86400000), donorName: 'Amit Patel' },
    { bagCode: 'BAG-BN-1009', bloodGroup: 'B-', storageRack: 'Cold Rack C-2', collectedAt: new Date(Date.now() - 10 * 86400000), expiresAt: new Date(Date.now() + 32 * 86400000), donorName: 'Karthik Raja' },
    { bagCode: 'BAG-ABP-1010', bloodGroup: 'AB+', storageRack: 'Cold Rack D-1', collectedAt: new Date(Date.now() - 6 * 86400000), expiresAt: new Date(Date.now() + 36 * 86400000), donorName: 'Ananya Roy' },
    { bagCode: 'BAG-ABN-1011', bloodGroup: 'AB-', storageRack: 'Cold Rack D-2', collectedAt: new Date(Date.now() - 18 * 86400000), expiresAt: new Date(Date.now() + 24 * 86400000), donorName: 'Meera Kulkarni' },
    { bagCode: 'BAG-OP-1012', bloodGroup: 'O+', storageRack: 'Cold Rack A-1', status: 'DISPENSED', collectedAt: new Date(Date.now() - 25 * 86400000), expiresAt: new Date(Date.now() + 17 * 86400000), donorName: 'Rahul Sharma' }
  ];

  for (const b of bloodBagsData) {
    await prisma.bloodBag.create({ data: b });
  }

  // Pre-seed emergency hospital requisitions
  const requestsData = [
    {
      requestCode: 'REQ-2026-081',
      patientName: 'Ramesh Kadam',
      bloodGroup: 'O-',
      unitsRequired: 1,
      hospital: 'Lilavati Hospital & Research Centre',
      city: 'Mumbai',
      doctorName: 'Dr. A. Mehta (Head of Trauma ICU)',
      urgency: 'Critical',
      status: 'PENDING'
    },
    {
      requestCode: 'REQ-2026-082',
      patientName: 'Kavita Menon',
      bloodGroup: 'B+',
      unitsRequired: 2,
      hospital: 'Apollo Hospitals Bannerghatta',
      city: 'Bengaluru',
      doctorName: 'Dr. Suresh Rao (Cardiac Surgery)',
      urgency: 'Urgent',
      status: 'APPROVED'
    },
    {
      requestCode: 'REQ-2026-083',
      patientName: 'Sanjay Aggarwal',
      bloodGroup: 'A+',
      unitsRequired: 1,
      hospital: 'Max Super Speciality Hospital',
      city: 'New Delhi',
      doctorName: 'Dr. Pooja Bhatia (Oncology Unit)',
      urgency: 'Critical',
      status: 'PENDING'
    },
    {
      requestCode: 'REQ-2026-084',
      patientName: 'Shalini Pillai',
      bloodGroup: 'AB-',
      unitsRequired: 1,
      hospital: 'Fortis Malar Hospital',
      city: 'Chennai',
      doctorName: 'Dr. C. Ramanathan (Obstetrics)',
      urgency: 'Standard',
      status: 'PENDING'
    },
    {
      requestCode: 'REQ-2026-085',
      patientName: 'Harish Bansal',
      bloodGroup: 'O+',
      unitsRequired: 1,
      hospital: 'Ruby Hall Clinic',
      city: 'Pune',
      doctorName: 'Dr. K. Joshi (Orthopedics)',
      urgency: 'Urgent',
      status: 'DISPENSED',
      dispensedBagCodes: 'BAG-OP-1012',
      dispensedAt: new Date(Date.now() - 2 * 86400000)
    }
  ];

  for (const req of requestsData) {
    await prisma.bloodRequest.create({ data: req });
  }

  console.log('✅ Seeding complete: Donors, Blood Bags, and Hospital Requests seeded.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
