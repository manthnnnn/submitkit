'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  Users, Filter, Search, ArrowUpDown, ChevronRight, CheckCircle2, 
  Clock, Mail, Phone, ExternalLink, Briefcase, Award, Sparkles, Zap 
} from 'lucide-react';
import { MOCK_CANDIDATES, MOCK_JOBS, Candidate, JobOpening } from '@/lib/mock-data';
import { calculateATSScore } from '@/lib/scoring';
import SkillBadge from '@/components/skill-badge';

export default function CandidatesPage() {
  const [candidates, setCandidates] = useState<Candidate[]>(MOCK_CANDIDATES);
  const [selectedJob, setSelectedJob] = useState<JobOpening>(MOCK_JOBS[0]);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'score' | 'experience' | 'name'>('score');

  // Compute scores for each candidate against selectedJob
  const scoredCandidates = candidates.map(c => {
    const res = calculateATSScore(c, selectedJob);
    return {
      ...c,
      atsScore: res.overallScore,
      atsGrade: res.grade,
      matchedCount: res.matchedRequiredSkills.length,
      missingCount: res.missingRequiredSkills.length,
    };
  });

  // Filter & Search
  const filteredCandidates = scoredCandidates.filter(c => {
    const matchesStatus = statusFilter === 'ALL' || c.status.toUpperCase() === statusFilter.toUpperCase();
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          c.skills.languages.some(l => l.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          c.skills.frameworks.some(f => f.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  // Sort
  const sortedCandidates = [...filteredCandidates].sort((a, b) => {
    if (sortBy === 'score') return b.atsScore - a.atsScore;
    if (sortBy === 'experience') return b.experienceYears - a.experienceYears;
    return a.name.localeCompare(b.name);
  });

  // Status Change Handler
  const handleStatusChange = (candId: string, newStatus: Candidate['status']) => {
    setCandidates(prev => prev.map(c => c.id === candId ? { ...c, status: newStatus } : c));
  };

  // Pipeline Metrics
  const pipelineStats = {
    total: candidates.length,
    screening: candidates.filter(c => c.status === 'Screening').length,
    shortlisted: candidates.filter(c => c.status === 'Shortlisted').length,
    interview: candidates.filter(c => c.status === 'Interview').length,
    offer: candidates.filter(c => c.status === 'Offer').length,
  };

  return (
    <div style={{ maxWidth: '1440px', margin: '0 auto', padding: '32px 24px' }}>
      {/* Header */}
      <div style={{ marginBottom: '28px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
          <span style={{
            padding: '3px 10px',
            borderRadius: '999px',
            fontSize: '0.72rem',
            fontWeight: 700,
            background: 'rgba(99, 102, 241, 0.15)',
            color: 'var(--primary-light)',
            border: '1px solid rgba(99, 102, 241, 0.3)',
            textTransform: 'uppercase',
          }}>
            Hiring Workflow Portal
          </span>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Comparative ATS Ranking & Funnel
          </span>
        </div>
        <h1 style={{ fontSize: '2.2rem', fontWeight: 800, letterSpacing: '-0.03em', color: '#ffffff' }}>
          Recruiter Candidate Leaderboard & Pipeline
        </h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', marginTop: '6px' }}>
          Benchmark and rank applicants dynamically based on compatibility with specific job requirements. Transition candidates across the recruitment pipeline.
        </p>
      </div>

      {/* Pipeline Summary Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '16px',
        marginBottom: '28px',
      }}>
        <div className="glass-panel" style={{ padding: '16px 20px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>
            Total Applicants
          </span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#ffffff', fontFamily: 'var(--font-mono)', marginTop: '4px' }}>
            {pipelineStats.total}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '16px 20px', borderLeft: '4px solid var(--accent-cyan)' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>
            In Screening
          </span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-cyan)', fontFamily: 'var(--font-mono)', marginTop: '4px' }}>
            {pipelineStats.screening}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '16px 20px', borderLeft: '4px solid var(--primary-light)' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>
            Shortlisted (ATS Pass)
          </span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--primary-light)', fontFamily: 'var(--font-mono)', marginTop: '4px' }}>
            {pipelineStats.shortlisted}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '16px 20px', borderLeft: '4px solid var(--accent-amber)' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>
            Interview Stage
          </span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-amber)', fontFamily: 'var(--font-mono)', marginTop: '4px' }}>
            {pipelineStats.interview}
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '16px 20px', borderLeft: '4px solid var(--accent-emerald)' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 600 }}>
            Offers Extended
          </span>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent-emerald)', fontFamily: 'var(--font-mono)', marginTop: '4px' }}>
            {pipelineStats.offer}
          </div>
        </div>
      </div>

      {/* Control Bar: Job Target Selector & Search & Filters */}
      <div className="glass-panel" style={{ padding: '20px', marginBottom: '24px' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '16px',
        }}>
          {/* Target Job Selector */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
              Rank Candidates For:
            </span>
            <select
              value={selectedJob.id}
              onChange={(e) => {
                const found = MOCK_JOBS.find(j => j.id === e.target.value);
                if (found) setSelectedJob(found);
              }}
              style={{
                padding: '8px 14px',
                borderRadius: '6px',
                background: 'rgba(9, 10, 16, 0.8)',
                border: '1px solid var(--border-subtle)',
                color: '#ffffff',
                fontSize: '0.85rem',
                outline: 'none',
                cursor: 'pointer',
              }}
            >
              {MOCK_JOBS.map((j) => (
                <option key={j.id} value={j.id} style={{ background: '#101322' }}>
                  {j.title} ({j.department})
                </option>
              ))}
            </select>
          </div>

          {/* Search Input */}
          <div style={{ position: 'relative', minWidth: '240px' }}>
            <Search size={14} color="var(--text-muted)" style={{ position: 'absolute', left: '12px', top: '12px' }} />
            <input
              type="text"
              placeholder="Search candidate, skill, title..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px 8px 34px',
                borderRadius: '6px',
                background: 'rgba(9, 10, 16, 0.8)',
                border: '1px solid var(--border-subtle)',
                color: '#ffffff',
                fontSize: '0.82rem',
                outline: 'none',
                boxSizing: 'border-box',
              }}
            />
          </div>

          {/* Sort By */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <ArrowUpDown size={14} color="var(--text-muted)" />
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              style={{
                padding: '6px 12px',
                borderRadius: '6px',
                background: 'rgba(9, 10, 16, 0.8)',
                border: '1px solid var(--border-subtle)',
                color: '#ffffff',
                fontSize: '0.82rem',
                outline: 'none',
                cursor: 'pointer',
              }}
            >
              <option value="score" style={{ background: '#101322' }}>ATS Compatibility Score</option>
              <option value="experience" style={{ background: '#101322' }}>Years of Experience</option>
              <option value="name" style={{ background: '#101322' }}>Candidate Name</option>
            </select>
          </div>

          {/* Status Filter Tabs */}
          <div style={{ display: 'flex', gap: '4px' }}>
            {['ALL', 'Screening', 'Shortlisted', 'Interview', 'Offer'].map((tab) => (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                style={{
                  padding: '6px 12px',
                  borderRadius: '6px',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  border: 'none',
                  background: statusFilter === tab ? 'var(--primary)' : 'rgba(255, 255, 255, 0.05)',
                  color: statusFilter === tab ? '#ffffff' : 'var(--text-secondary)',
                  transition: 'all 0.2s ease',
                }}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Candidates Ranked Table / Cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {sortedCandidates.length === 0 ? (
          <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
            No applicants match your current query or stage filter.
          </div>
        ) : (
          sortedCandidates.map((candidate, rank) => {
            let scoreColor = 'var(--accent-emerald)';
            if (candidate.atsScore < 55) scoreColor = 'var(--accent-rose)';
            else if (candidate.atsScore < 70) scoreColor = 'var(--accent-amber)';
            else if (candidate.atsScore < 85) scoreColor = 'var(--primary-light)';

            return (
              <div
                key={candidate.id}
                className="glass-panel glass-panel-interactive candidate-row-grid"
                style={{
                  padding: '18px 20px',
                }}
              >
                {/* Rank & Score Pill */}
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 700 }}>
                    #{rank + 1}
                  </div>
                  <div style={{
                    fontSize: '1.25rem',
                    fontWeight: 800,
                    color: scoreColor,
                    fontFamily: 'var(--font-mono)',
                    marginTop: '2px',
                  }}>
                    {candidate.atsScore}%
                  </div>
                  <div style={{
                    fontSize: '0.65rem',
                    fontWeight: 700,
                    color: scoreColor,
                    background: 'rgba(255, 255, 255, 0.05)',
                    padding: '1px 6px',
                    borderRadius: '4px',
                    marginTop: '2px',
                  }}>
                    {candidate.atsGrade}
                  </div>
                </div>

                {/* Candidate Info */}
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{
                      width: '32px',
                      height: '32px',
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, var(--primary), var(--secondary))',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '0.85rem',
                      fontWeight: 700,
                      color: '#ffffff',
                    }}>
                      {candidate.name.charAt(0)}
                    </div>
                    <div>
                      <div style={{ fontSize: '1rem', fontWeight: 700, color: '#ffffff' }}>
                        {candidate.name}
                      </div>
                      <div style={{ fontSize: '0.78rem', color: 'var(--primary-light)' }}>
                        {candidate.title} • <span style={{ color: 'var(--text-muted)' }}>{candidate.experienceYears}y exp</span>
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: '14px', marginTop: '8px', fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                    <span>{candidate.email}</span>
                    <span>•</span>
                    <span>{candidate.location}</span>
                  </div>
                </div>

                {/* Skills Preview */}
                <div>
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '6px' }}>
                    Key Extracted Stack
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                    {candidate.skills.languages.slice(0, 2).map(s => (
                      <SkillBadge key={s} label={s} category="languages" />
                    ))}
                    {candidate.skills.frameworks.slice(0, 2).map(s => (
                      <SkillBadge key={s} label={s} category="frameworks" />
                    ))}
                    {candidate.skills.cloudDevOps.slice(0, 1).map(s => (
                      <SkillBadge key={s} label={s} category="cloudDevOps" />
                    ))}
                  </div>
                </div>

                {/* Stage Funnel Selector */}
                <div>
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '6px' }}>
                    Hiring Stage
                  </div>
                  <select
                    value={candidate.status}
                    onChange={(e) => handleStatusChange(candidate.id, e.target.value as any)}
                    style={{
                      padding: '6px 10px',
                      borderRadius: '6px',
                      background: 'rgba(9, 10, 16, 0.9)',
                      border: '1px solid var(--border-subtle)',
                      color: candidate.status === 'Offer' ? 'var(--accent-emerald)' :
                             candidate.status === 'Interview' ? 'var(--accent-amber)' :
                             candidate.status === 'Shortlisted' ? 'var(--primary-light)' : '#ffffff',
                      fontSize: '0.78rem',
                      fontWeight: 600,
                      outline: 'none',
                      cursor: 'pointer',
                      width: '100%',
                    }}
                  >
                    <option value="Applied" style={{ background: '#101322', color: '#fff' }}>Applied</option>
                    <option value="Screening" style={{ background: '#101322', color: '#fff' }}>Screening</option>
                    <option value="Shortlisted" style={{ background: '#101322', color: '#fff' }}>Shortlisted</option>
                    <option value="Interview" style={{ background: '#101322', color: '#fff' }}>Interview</option>
                    <option value="Offer" style={{ background: '#101322', color: '#fff' }}>Offer Extended</option>
                  </select>
                </div>

                {/* Actions */}
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
                  <Link
                    href={`/matcher`}
                    className="btn-secondary"
                    style={{ padding: '6px 12px', fontSize: '0.76rem' }}
                  >
                    <Zap size={13} color="var(--primary-light)" />
                    <span>Deep ATS</span>
                  </Link>
                  <Link
                    href={`/interview`}
                    className="btn-primary"
                    style={{ padding: '6px 12px', fontSize: '0.76rem' }}
                  >
                    <Sparkles size={13} />
                    <span>Viva Prep</span>
                  </Link>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
