'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, FileText, Calendar, Settings, Activity, Users, LogOut } from 'lucide-react';

export default function Sidebar() {
  const pathname = usePathname();

  const navLinks = [
    { name: 'Dashboard', href: '/dashboard', icon: <LayoutDashboard size={20} /> },
    { name: 'EHR Records', href: '/records', icon: <FileText size={20} /> },
    { name: 'Appointments', href: '/appointments', icon: <Calendar size={20} /> },
    { name: 'Vitals Monitor', href: '/vitals', icon: <Activity size={20} /> },
    { name: 'Care Team', href: '/team', icon: <Users size={20} /> },
    { name: 'Settings', href: '/settings', icon: <Settings size={20} /> },
  ];

  if (pathname === '/') return null; // Don't show sidebar on login/landing page

  return (
    <aside style={{
      width: '260px',
      height: '100vh',
      backgroundColor: 'var(--surface-white)',
      borderRight: '1px solid var(--border-light)',
      position: 'fixed',
      display: 'flex',
      flexDirection: 'column',
      padding: '24px 16px',
      zIndex: 50
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '0 12px', marginBottom: '40px' }}>
        <div style={{ background: 'var(--primary-blue)', padding: '8px', borderRadius: '10px' }}>
          <Activity size={24} color="white" />
        </div>
        <span style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--foreground)' }}>
          Health<span style={{ color: 'var(--primary-blue)' }}>Sync</span>
        </span>
      </div>

      <nav style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <p style={{ padding: '0 12px', fontSize: '0.75rem', fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', marginBottom: '8px' }}>
          Main Menu
        </p>
        
        {navLinks.map((link) => {
          const isActive = pathname === link.href || pathname.startsWith(link.href + '/');
          return (
            <Link key={link.name} href={link.href} style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              padding: '12px',
              borderRadius: 'var(--radius-sm)',
              backgroundColor: isActive ? 'var(--primary-blue-alpha)' : 'transparent',
              color: isActive ? 'var(--primary-blue)' : '#475569',
              fontWeight: isActive ? 600 : 500,
              transition: 'all 0.2s',
              border: '1px solid transparent',
              borderColor: isActive ? 'rgba(37, 99, 235, 0.2)' : 'transparent'
            }} className="nav-item">
              {link.icon}
              {link.name}
            </Link>
          );
        })}
      </nav>

      <div style={{ borderTop: '1px solid var(--border-light)', paddingTop: '20px', marginTop: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px' }}>
          <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: '#e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 600, color: '#475569' }}>
            JS
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: '0.9rem', fontWeight: 600, color: 'var(--foreground)', margin: 0 }}>John Smith</p>
            <p style={{ fontSize: '0.75rem', color: '#64748b', margin: 0 }}>Patient ID: 9482-B</p>
          </div>
        </div>
        <Link href="/" style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '12px',
          borderRadius: 'var(--radius-sm)',
          color: 'var(--alert-red)',
          fontWeight: 500,
          marginTop: '8px'
        }} className="nav-item-logout">
          <LogOut size={20} />
          Sign Out
        </Link>
      </div>

      <style jsx>{`
        .nav-item:hover {
          background-color: #f1f5f9;
        }
        .nav-item-logout:hover {
          background-color: var(--alert-red-alpha);
        }
      `}</style>
    </aside>
  );
}
