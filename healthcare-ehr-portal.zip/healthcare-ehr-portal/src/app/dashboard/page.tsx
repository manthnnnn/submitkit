'use client';

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Activity, HeartPulse, Stethoscope, FileText, Calendar, Clock, Download } from 'lucide-react';

const vitalsData = [
  { time: '08:00', hr: 72, bp: 118, o2: 98 },
  { time: '10:00', hr: 75, bp: 120, o2: 98 },
  { time: '12:00', hr: 82, bp: 125, o2: 97 },
  { time: '14:00', hr: 78, bp: 122, o2: 99 },
  { time: '16:00', hr: 71, bp: 119, o2: 99 },
  { time: '18:00', hr: 74, bp: 121, o2: 98 },
  { time: '20:00', hr: 68, bp: 115, o2: 99 },
];

export default function Dashboard() {
  return (
    <div style={{ maxWidth: '1200px', width: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px' }}>
        <div>
          <h1 style={{ fontSize: '1.8rem', fontWeight: 700, margin: '0 0 8px 0' }}>Patient Overview</h1>
          <p style={{ color: '#64748b', margin: 0 }}>Welcome back, John. Here is your daily health summary.</p>
        </div>
        <button className="btn-primary">
          <Download size={18} /> Download Full Report
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '20px', marginBottom: '32px' }}>
        <div className="clinical-card" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ background: 'var(--alert-red-alpha)', padding: '16px', borderRadius: '50%' }}>
            <HeartPulse size={28} color="var(--alert-red)" />
          </div>
          <div>
            <p style={{ margin: '0 0 4px 0', fontSize: '0.85rem', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Heart Rate</p>
            <h3 style={{ margin: 0, fontSize: '1.8rem', fontWeight: 700 }}>72 <span style={{ fontSize: '1rem', fontWeight: 500, color: '#94a3b8' }}>bpm</span></h3>
          </div>
        </div>
        
        <div className="clinical-card" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ background: 'var(--primary-blue-alpha)', padding: '16px', borderRadius: '50%' }}>
            <Activity size={28} color="var(--primary-blue)" />
          </div>
          <div>
            <p style={{ margin: '0 0 4px 0', fontSize: '0.85rem', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Blood Pressure</p>
            <h3 style={{ margin: 0, fontSize: '1.8rem', fontWeight: 700 }}>118/75 <span style={{ fontSize: '1rem', fontWeight: 500, color: '#94a3b8' }}>mmHg</span></h3>
          </div>
        </div>

        <div className="clinical-card" style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ background: 'var(--success-green-alpha)', padding: '16px', borderRadius: '50%' }}>
            <Activity size={28} color="var(--success-green)" />
          </div>
          <div>
            <p style={{ margin: '0 0 4px 0', fontSize: '0.85rem', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Oxygen Level</p>
            <h3 style={{ margin: 0, fontSize: '1.8rem', fontWeight: 700 }}>99 <span style={{ fontSize: '1rem', fontWeight: 500, color: '#94a3b8' }}>%</span></h3>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '32px' }}>
        
        {/* Main Chart Area */}
        <div className="clinical-card" style={{ height: '420px', display: 'flex', flexDirection: 'column' }}>
          <h2 style={{ fontSize: '1.2rem', fontWeight: 600, marginBottom: '24px' }}>Vitals Trend (24h)</h2>
          <div style={{ flex: 1, width: '100%', minHeight: 0 }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={vitalsData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorHr" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--alert-red)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="var(--alert-red)" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorBp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--primary-blue)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="var(--primary-blue)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-md)' }}
                  labelStyle={{ fontWeight: 600, color: 'var(--foreground)' }}
                />
                <Area type="monotone" dataKey="hr" name="Heart Rate" stroke="var(--alert-red)" strokeWidth={3} fillOpacity={1} fill="url(#colorHr)" />
                <Area type="monotone" dataKey="bp" name="Systolic BP" stroke="var(--primary-blue)" strokeWidth={3} fillOpacity={1} fill="url(#colorBp)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
          
          <div className="clinical-card">
            <h2 style={{ fontSize: '1.1rem', fontWeight: 600, marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Stethoscope size={18} color="var(--primary-blue)" /> AI Health Summary
            </h2>
            <p style={{ fontSize: '0.9rem', color: '#475569', lineHeight: 1.6, margin: 0 }}>
              Your vitals have remained highly stable over the last 7 days. Heart rate variability is within the optimal threshold for your age group. Blood pressure shows a slight elevation during midday but normalizes by evening. Continue prescribed medication plan.
            </p>
          </div>

          <div className="clinical-card">
            <h2 style={{ fontSize: '1.1rem', fontWeight: 600, marginBottom: '16px' }}>Upcoming Appointments</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
                <div style={{ background: '#f1f5f9', padding: '10px', borderRadius: '8px', textAlign: 'center', minWidth: '50px' }}>
                  <span style={{ display: 'block', fontSize: '0.75rem', fontWeight: 600, color: 'var(--primary-blue)', textTransform: 'uppercase' }}>Oct</span>
                  <span style={{ display: 'block', fontSize: '1.2rem', fontWeight: 700 }}>14</span>
                </div>
                <div>
                  <h4 style={{ margin: '0 0 4px 0', fontSize: '0.95rem', fontWeight: 600 }}>Dr. Sarah Jenkins</h4>
                  <p style={{ margin: '0 0 4px 0', fontSize: '0.85rem', color: '#64748b' }}>Cardiology Follow-up</p>
                  <p style={{ margin: 0, fontSize: '0.8rem', color: '#94a3b8', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <Clock size={12} /> 10:30 AM
                  </p>
                </div>
              </div>
              
              <div style={{ borderTop: '1px solid #e2e8f0', paddingTop: '16px', display: 'flex', alignItems: 'flex-start', gap: '12px' }}>
                <div style={{ background: '#f1f5f9', padding: '10px', borderRadius: '8px', textAlign: 'center', minWidth: '50px' }}>
                  <span style={{ display: 'block', fontSize: '0.75rem', fontWeight: 600, color: '#64748b', textTransform: 'uppercase' }}>Nov</span>
                  <span style={{ display: 'block', fontSize: '1.2rem', fontWeight: 700 }}>02</span>
                </div>
                <div>
                  <h4 style={{ margin: '0 0 4px 0', fontSize: '0.95rem', fontWeight: 600 }}>General Blood Test</h4>
                  <p style={{ margin: '0 0 4px 0', fontSize: '0.85rem', color: '#64748b' }}>Pathology Lab</p>
                  <p style={{ margin: 0, fontSize: '0.8rem', color: '#94a3b8', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <Clock size={12} /> 08:00 AM
                  </p>
                </div>
              </div>
            </div>
            <button className="btn-outline" style={{ width: '100%', marginTop: '20px', justifyContent: 'center' }}>
              View All Schedule
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
