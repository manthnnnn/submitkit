import Link from 'next/link';
import { Activity, ShieldCheck, HeartPulse } from 'lucide-react';

export default function Home() {
  return (
    <div style={{ 
      minHeight: '100vh', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #f0f4f8 0%, #d9e2ec 100%)',
      padding: '20px'
    }}>
      <div className="clinical-card" style={{ maxWidth: '400px', width: '100%', padding: '40px' }}>
        
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: '32px' }}>
          <div style={{ background: 'var(--primary-blue)', padding: '12px', borderRadius: '12px', marginBottom: '16px' }}>
            <Activity size={32} color="white" />
          </div>
          <h1 style={{ fontSize: '1.8rem', fontWeight: 700, color: 'var(--foreground)', margin: '0 0 8px 0' }}>HealthSync Portal</h1>
          <p style={{ color: '#64748b', textAlign: 'center', fontSize: '0.95rem' }}>Centralized Electronic Health Records & Patient Care</p>
        </div>

        <form style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 500, color: '#334155' }}>
              Patient ID or Email
            </label>
            <input type="text" className="clinical-input" placeholder="e.g. 9482-B" defaultValue="9482-B" />
          </div>
          
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 500, color: '#334155' }}>
              Secure Password
            </label>
            <input type="password" className="clinical-input" placeholder="••••••••" defaultValue="password123" />
          </div>

          <Link href="/dashboard" style={{ width: '100%' }}>
            <button type="button" className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '12px', marginTop: '10px' }}>
              <ShieldCheck size={18} />
              Secure Login
            </button>
          </Link>
        </form>

        <div style={{ marginTop: '32px', borderTop: '1px solid var(--border-light)', paddingTop: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', color: '#64748b', fontSize: '0.85rem' }}>
          <HeartPulse size={16} color="var(--primary-blue)" />
          HIPAA Compliant System
        </div>
        
      </div>
    </div>
  );
}
