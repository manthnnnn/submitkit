'use client';

import { FileText, Download, Lock, Search, Filter } from 'lucide-react';

const mockRecords = [
  { id: 'LAB-9921', date: '2023-10-01', title: 'Comprehensive Metabolic Panel', provider: 'Dr. Sarah Jenkins', status: 'Available', type: 'Lab Result' },
  { id: 'IMG-4820', date: '2023-08-15', title: 'Chest X-Ray (AP/LAT)', provider: 'Radiology Dept', status: 'Available', type: 'Imaging' },
  { id: 'RX-1029', date: '2023-06-22', title: 'Atorvastatin 20mg Prescription', provider: 'Dr. Marcus Webb', status: 'Active', type: 'Prescription' },
  { id: 'VAC-0045', date: '2023-01-10', title: 'Influenza Vaccine Record', provider: 'City Clinic', status: 'Verified', type: 'Immunization' },
  { id: 'LAB-8810', date: '2022-11-05', title: 'Lipid Panel', provider: 'Dr. Sarah Jenkins', status: 'Available', type: 'Lab Result' },
];

export default function RecordsPage() {
  return (
    <div style={{ maxWidth: '1200px', width: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px' }}>
        <div>
          <h1 style={{ fontSize: '1.8rem', fontWeight: 700, margin: '0 0 8px 0' }}>Electronic Health Records</h1>
          <p style={{ color: '#64748b', margin: 0, display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Lock size={14} color="var(--success-green)" /> End-to-end encrypted vault
          </p>
        </div>
        <button className="btn-primary">
          <FileText size={18} /> Request New Record
        </button>
      </div>

      <div className="clinical-card" style={{ padding: '0', overflow: 'hidden' }}>
        
        {/* Toolbar */}
        <div style={{ padding: '20px', borderBottom: '1px solid var(--border-light)', display: 'flex', gap: '16px', alignItems: 'center', background: '#f8fafc' }}>
          <div style={{ flex: 1, position: 'relative' }}>
            <Search size={18} color="#94a3b8" style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)' }} />
            <input 
              type="text" 
              className="clinical-input" 
              placeholder="Search records by ID, title, or provider..." 
              style={{ paddingLeft: '40px', background: 'white' }}
            />
          </div>
          <button className="btn-outline" style={{ background: 'white' }}>
            <Filter size={18} /> Filter
          </button>
        </div>

        {/* Table */}
        <div style={{ overflowX: 'auto' }}>
          <table className="clinical-table">
            <thead>
              <tr>
                <th>Record ID</th>
                <th>Date</th>
                <th>Title / Description</th>
                <th>Provider</th>
                <th>Type</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {mockRecords.map((record) => (
                <tr key={record.id}>
                  <td style={{ fontWeight: 600, color: 'var(--primary-blue)' }}>{record.id}</td>
                  <td>{record.date}</td>
                  <td style={{ fontWeight: 500 }}>{record.title}</td>
                  <td style={{ color: '#475569' }}>{record.provider}</td>
                  <td>
                    <span style={{ 
                      padding: '4px 8px', 
                      background: '#f1f5f9', 
                      borderRadius: '4px', 
                      fontSize: '0.8rem', 
                      fontWeight: 500,
                      color: '#475569'
                    }}>
                      {record.type}
                    </span>
                  </td>
                  <td>
                    <span className={record.status === 'Active' ? 'badge-primary' : 'badge-success'}>
                      {record.status}
                    </span>
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <button style={{ 
                      background: 'transparent', 
                      border: 'none', 
                      color: 'var(--primary-blue)', 
                      cursor: 'pointer',
                      padding: '8px',
                      borderRadius: '4px',
                      transition: 'background 0.2s'
                    }} className="action-btn">
                      <Download size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      <style jsx>{`
        .action-btn:hover {
          background: var(--primary-blue-alpha) !important;
        }
      `}</style>
    </div>
  );
}
