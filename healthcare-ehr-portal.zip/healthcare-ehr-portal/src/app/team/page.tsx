import { Users, Mail, Phone, MessageSquare } from 'lucide-react';

export default function TeamPage() {
  return (
    <div style={{ maxWidth: '1200px', width: '100%' }}>
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontSize: '1.8rem', fontWeight: 700, margin: '0 0 8px 0' }}>Care Team</h1>
        <p style={{ color: '#64748b', margin: 0 }}>Direct secure communication with your primary and specialist doctors.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        
        {/* Doctor 1 */}
        <div className="clinical-card" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ width: '60px', height: '60px', borderRadius: '50%', background: '#e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#475569', fontWeight: 700, fontSize: '1.2rem' }}>
              MW
            </div>
            <div>
              <h2 style={{ margin: '0 0 4px 0', fontSize: '1.1rem', fontWeight: 600 }}>Dr. Marcus Webb</h2>
              <span className="badge-primary">Primary Care Physician</span>
            </div>
          </div>
          <p style={{ color: '#64748b', fontSize: '0.9rem', lineHeight: 1.5, margin: 0 }}>
            Board-certified in Internal Medicine. Your main point of contact for general health and referrals.
          </p>
          <div style={{ display: 'flex', gap: '10px', marginTop: 'auto', paddingTop: '16px', borderTop: '1px solid var(--border-light)' }}>
            <button className="btn-primary" style={{ flex: 1, justifyContent: 'center' }}><MessageSquare size={16} /> Message</button>
            <button className="btn-outline" style={{ padding: '10px' }}><Phone size={16} /></button>
          </div>
        </div>

        {/* Doctor 2 */}
        <div className="clinical-card" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ width: '60px', height: '60px', borderRadius: '50%', background: '#e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#475569', fontWeight: 700, fontSize: '1.2rem' }}>
              SJ
            </div>
            <div>
              <h2 style={{ margin: '0 0 4px 0', fontSize: '1.1rem', fontWeight: 600 }}>Dr. Sarah Jenkins</h2>
              <span className="badge-alert">Cardiologist</span>
            </div>
          </div>
          <p style={{ color: '#64748b', fontSize: '0.9rem', lineHeight: 1.5, margin: 0 }}>
            Specialist managing your recent hypertension and ECG monitoring plan.
          </p>
          <div style={{ display: 'flex', gap: '10px', marginTop: 'auto', paddingTop: '16px', borderTop: '1px solid var(--border-light)' }}>
            <button className="btn-primary" style={{ flex: 1, justifyContent: 'center' }}><MessageSquare size={16} /> Message</button>
            <button className="btn-outline" style={{ padding: '10px' }}><Phone size={16} /></button>
          </div>
        </div>

      </div>
    </div>
  );
}
