'use client';

import { Activity, HeartPulse, Droplet } from 'lucide-react';

export default function VitalsPage() {
  return (
    <div style={{ maxWidth: '1200px', width: '100%' }}>
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontSize: '1.8rem', fontWeight: 700, margin: '0 0 8px 0' }}>Comprehensive Vitals</h1>
        <p style={{ color: '#64748b', margin: 0 }}>Detailed historical tracking of your connected health devices.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px' }}>
        
        <div className="clinical-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
            <div style={{ background: 'var(--alert-red-alpha)', padding: '12px', borderRadius: '50%' }}>
              <HeartPulse size={24} color="var(--alert-red)" />
            </div>
            <h2 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 600 }}>Heart Rate History</h2>
          </div>
          <div style={{ height: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px dashed var(--border-light)', borderRadius: '8px', background: '#f8fafc' }}>
            <p style={{ color: '#94a3b8', fontSize: '0.9rem', fontWeight: 500 }}>Syncing Apple Watch data...</p>
          </div>
        </div>

        <div className="clinical-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
            <div style={{ background: 'var(--primary-blue-alpha)', padding: '12px', borderRadius: '50%' }}>
              <Activity size={24} color="var(--primary-blue)" />
            </div>
            <h2 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 600 }}>Blood Pressure</h2>
          </div>
          <div style={{ height: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px dashed var(--border-light)', borderRadius: '8px', background: '#f8fafc' }}>
            <p style={{ color: '#94a3b8', fontSize: '0.9rem', fontWeight: 500 }}>Omron Monitor paired. Ready for reading.</p>
          </div>
        </div>

        <div className="clinical-card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
            <div style={{ background: 'var(--success-green-alpha)', padding: '12px', borderRadius: '50%' }}>
              <Droplet size={24} color="var(--success-green)" />
            </div>
            <h2 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 600 }}>Blood Glucose</h2>
          </div>
          <div style={{ height: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px dashed var(--border-light)', borderRadius: '8px', background: '#f8fafc' }}>
            <p style={{ color: '#94a3b8', fontSize: '0.9rem', fontWeight: 500 }}>Dexcom G6 data up to date.</p>
          </div>
        </div>

      </div>
    </div>
  );
}
