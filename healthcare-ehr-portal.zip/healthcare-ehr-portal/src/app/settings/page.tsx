import { Settings, Shield, Bell, User } from 'lucide-react';

export default function SettingsPage() {
  return (
    <div style={{ maxWidth: '1200px', width: '100%' }}>
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontSize: '1.8rem', fontWeight: 700, margin: '0 0 8px 0' }}>Account Settings</h1>
        <p style={{ color: '#64748b', margin: 0 }}>Manage your preferences, security, and notifications.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '32px' }}>
        
        {/* Settings Nav */}
        <div className="clinical-card" style={{ padding: '16px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <button className="btn-primary" style={{ justifyContent: 'flex-start', background: 'var(--primary-blue-alpha)', color: 'var(--primary-blue)', boxShadow: 'none' }}>
              <User size={18} /> Personal Info
            </button>
            <button className="btn-outline" style={{ border: 'none', color: '#475569', justifyContent: 'flex-start' }}>
              <Shield size={18} /> Security & HIPAA
            </button>
            <button className="btn-outline" style={{ border: 'none', color: '#475569', justifyContent: 'flex-start' }}>
              <Bell size={18} /> Notifications
            </button>
          </div>
        </div>

        {/* Settings Content */}
        <div className="clinical-card">
          <h2 style={{ fontSize: '1.2rem', fontWeight: 600, borderBottom: '1px solid var(--border-light)', paddingBottom: '16px', margin: '0 0 24px 0' }}>Personal Information</h2>
          
          <form style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 500, color: '#334155' }}>First Name</label>
                <input type="text" className="clinical-input" defaultValue="John" />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 500, color: '#334155' }}>Last Name</label>
                <input type="text" className="clinical-input" defaultValue="Smith" />
              </div>
            </div>
            
            <div>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 500, color: '#334155' }}>Email Address</label>
              <input type="email" className="clinical-input" defaultValue="john.smith@example.com" />
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', fontWeight: 500, color: '#334155' }}>Emergency Contact Phone</label>
              <input type="tel" className="clinical-input" defaultValue="+1 (555) 019-8231" />
            </div>

            <div style={{ paddingTop: '20px', borderTop: '1px solid var(--border-light)' }}>
              <button type="button" className="btn-primary">Save Changes</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  );
}
