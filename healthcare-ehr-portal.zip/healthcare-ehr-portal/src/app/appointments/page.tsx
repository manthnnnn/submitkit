import { Calendar, Clock, Video, User } from 'lucide-react';

export default function AppointmentsPage() {
  return (
    <div style={{ maxWidth: '1200px', width: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px' }}>
        <div>
          <h1 style={{ fontSize: '1.8rem', fontWeight: 700, margin: '0 0 8px 0' }}>Appointments</h1>
          <p style={{ color: '#64748b', margin: 0 }}>Manage your upcoming visits and telehealth sessions.</p>
        </div>
        <button className="btn-primary">
          <Calendar size={18} /> Schedule New
        </button>
      </div>

      <div className="clinical-card" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <h2 style={{ fontSize: '1.2rem', fontWeight: 600, borderBottom: '1px solid var(--border-light)', paddingBottom: '16px', margin: 0 }}>Upcoming Schedule</h2>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '24px', padding: '20px', background: '#f8fafc', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-light)' }}>
          <div style={{ background: 'white', padding: '16px', borderRadius: '12px', textAlign: 'center', minWidth: '80px', border: '1px solid var(--border-light)', boxShadow: 'var(--shadow-sm)' }}>
            <span style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: 'var(--primary-blue)', textTransform: 'uppercase' }}>October</span>
            <span style={{ display: 'block', fontSize: '1.8rem', fontWeight: 800 }}>14</span>
          </div>
          
          <div style={{ flex: 1 }}>
            <h3 style={{ margin: '0 0 8px 0', fontSize: '1.1rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
              Dr. Sarah Jenkins <span className="badge-primary">Cardiology</span>
            </h3>
            <p style={{ margin: '0 0 8px 0', color: '#475569', fontSize: '0.95rem' }}>Routine 6-month follow-up and ECG review.</p>
            <div style={{ display: 'flex', gap: '16px', color: '#64748b', fontSize: '0.85rem', fontWeight: 500 }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><Clock size={14} /> 10:30 AM - 11:00 AM</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><Video size={14} /> Telehealth Video</span>
            </div>
          </div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <button className="btn-primary" style={{ padding: '8px 16px', fontSize: '0.85rem' }}>Join Call</button>
            <button className="btn-outline" style={{ padding: '8px 16px', fontSize: '0.85rem' }}>Reschedule</button>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '24px', padding: '20px', background: 'white', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-light)' }}>
          <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '12px', textAlign: 'center', minWidth: '80px', border: '1px solid var(--border-light)' }}>
            <span style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>November</span>
            <span style={{ display: 'block', fontSize: '1.8rem', fontWeight: 800 }}>02</span>
          </div>
          
          <div style={{ flex: 1 }}>
            <h3 style={{ margin: '0 0 8px 0', fontSize: '1.1rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
              General Blood Panel <span className="badge-alert">Required</span>
            </h3>
            <p style={{ margin: '0 0 8px 0', color: '#475569', fontSize: '0.95rem' }}>Fasting blood test at City Central Pathology Lab.</p>
            <div style={{ display: 'flex', gap: '16px', color: '#64748b', fontSize: '0.85rem', fontWeight: 500 }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><Clock size={14} /> 08:00 AM</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><User size={14} /> In-Person Visit</span>
            </div>
          </div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <button className="btn-outline" style={{ padding: '8px 16px', fontSize: '0.85rem' }}>Get Directions</button>
          </div>
        </div>

      </div>
    </div>
  );
}
