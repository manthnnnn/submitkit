import Link from 'next/link';
import { ArrowRight, Zap, Leaf, TrendingDown } from 'lucide-react';

export default function Home() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', overflow: 'hidden' }}>
      
      {/* Hero Section */}
      <section style={{
        minHeight: '80vh',
        width: '100%',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        padding: '0 20px',
        position: 'relative'
      }}>
        
        {/* Decorative Background Elements */}
        <div style={{
          position: 'absolute',
          top: '20%',
          left: '10%',
          width: '300px',
          height: '300px',
          background: 'var(--color-primary)',
          filter: 'blur(150px)',
          opacity: 0.2,
          zIndex: -1
        }} className="animate-pulse-glow" />
        
        <div style={{
          position: 'absolute',
          bottom: '10%',
          right: '10%',
          width: '400px',
          height: '400px',
          background: 'var(--color-secondary)',
          filter: 'blur(200px)',
          opacity: 0.15,
          zIndex: -1
        }} className="animate-pulse-glow" />

        <div style={{ display: 'inline-block', marginBottom: '20px', padding: '8px 16px', borderRadius: '50px', background: 'rgba(0, 240, 255, 0.1)', border: '1px solid rgba(0, 240, 255, 0.2)', color: 'var(--color-primary)', fontWeight: 600, fontSize: '0.9rem', letterSpacing: '1px' }}>
          NEXT-GEN AI PREDICTIONS 🚀
        </div>
        
        <h1 style={{ fontFamily: 'Outfit, sans-serif', fontSize: 'clamp(3rem, 6vw, 5rem)', fontWeight: 800, lineHeight: 1.1, marginBottom: '24px', maxWidth: '1000px' }}>
          Optimize Flights. <br/>
          <span style={{ background: 'linear-gradient(90deg, var(--color-primary), #fff)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            Minimize Fuel.
          </span>
        </h1>
        
        <p style={{ fontSize: '1.2rem', color: 'rgba(255, 255, 255, 0.7)', maxWidth: '600px', marginBottom: '40px', lineHeight: 1.6 }}>
          AeroFuel AI leverages machine learning and real-time weather models to predict aviation fuel consumption with 99.2% accuracy. Reduce costs and carbon footprint instantly.
        </p>
        
        <div style={{ display: 'flex', gap: '20px' }}>
          <Link href="/dashboard">
            <button className="btn-premium" style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '1.1rem', padding: '16px 32px' }}>
              Launch Predictor
              <ArrowRight size={20} />
            </button>
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section style={{ width: '100%', maxWidth: '1200px', padding: '80px 20px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '30px' }}>
        
        <div className="glass-panel animate-float" style={{ padding: '40px 30px', textAlign: 'left', animationDelay: '0s' }}>
          <div style={{ background: 'rgba(0, 240, 255, 0.1)', width: '60px', height: '60px', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '20px', color: 'var(--color-primary)' }}>
            <Zap size={30} />
          </div>
          <h3 style={{ fontSize: '1.5rem', marginBottom: '16px', fontFamily: 'Outfit, sans-serif' }}>AI Precision</h3>
          <p style={{ color: 'rgba(255, 255, 255, 0.6)', lineHeight: 1.6 }}>Advanced neural networks analyze historical data, payload, and weather to provide the most accurate fuel estimates.</p>
        </div>

        <div className="glass-panel animate-float" style={{ padding: '40px 30px', textAlign: 'left', animationDelay: '1s' }}>
          <div style={{ background: 'rgba(112, 0, 255, 0.1)', width: '60px', height: '60px', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '20px', color: 'var(--color-secondary)' }}>
            <TrendingDown size={30} />
          </div>
          <h3 style={{ fontSize: '1.5rem', marginBottom: '16px', fontFamily: 'Outfit, sans-serif' }}>Cost Reduction</h3>
          <p style={{ color: 'rgba(255, 255, 255, 0.6)', lineHeight: 1.6 }}>Avoid tankering unnecessarily. Optimize your fuel upload for every flight phase and save millions annually.</p>
        </div>

        <div className="glass-panel animate-float" style={{ padding: '40px 30px', textAlign: 'left', animationDelay: '2s' }}>
          <div style={{ background: 'rgba(0, 255, 128, 0.1)', width: '60px', height: '60px', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '20px', color: '#00ff80' }}>
            <Leaf size={30} />
          </div>
          <h3 style={{ fontSize: '1.5rem', marginBottom: '16px', fontFamily: 'Outfit, sans-serif' }}>Eco-Friendly</h3>
          <p style={{ color: 'rgba(255, 255, 255, 0.6)', lineHeight: 1.6 }}>Every kg of fuel saved reduces carbon emissions by 3.16 kg. Track and minimize your airline's carbon footprint.</p>
        </div>

      </section>
    </div>
  );
}
